const assert = require("assert");
const { layoutSheet, mmToPx } = require("../.test-build/config/passport.js");
const { parseColor } = require("../.test-build/config/backgrounds.js");
const { identityWarnings } = require("../.test-build/engine/identity-policy.js");
const { reducer, initialState, DEFAULT_EDIT } = require("../.test-build/state/reducer.js");

let passed = 0;
const t = (name, fn) => { fn(); passed++; console.log("  ok  " + name); };

console.log("passport layout");
t("40x50mm on 4x6in sheet with 3mm margin fits multiple photos", () => {
  const l = layoutSheet({ photo: { widthMm: 40, heightMm: 50 }, sheet: { widthMm: 101.6, heightMm: 152.4 }, marginMm: 3, gapMm: 2, copies: 99 });
  assert.strictEqual(l.columns, 2); // (95.6+2)/(42) = 2.32 -> 2
  assert.strictEqual(l.rows, 2);    // (146.4+2)/52 = 2.85 -> 2
  assert.strictEqual(l.capacity, 4);
  assert.strictEqual(l.placed, 4, "placed is capped at capacity");
});
t("copies below capacity are placed exactly", () => {
  const l = layoutSheet({ photo: { widthMm: 35, heightMm: 45 }, sheet: { widthMm: 210, heightMm: 297 }, marginMm: 5, gapMm: 2, copies: 3 });
  assert.strictEqual(l.placed, 3);
  assert.strictEqual(l.positions.length, 3);
  assert.deepStrictEqual(l.positions[0], { x: 5, y: 5 });
  assert.deepStrictEqual(l.positions[1], { x: 42, y: 5 });
});
t("oversized photo reports no fit instead of overflowing", () => {
  const l = layoutSheet({ photo: { widthMm: 300, heightMm: 300 }, sheet: { widthMm: 210, heightMm: 297 }, marginMm: 0, gapMm: 0, copies: 1 });
  assert.strictEqual(l.fitsAny, false);
  assert.strictEqual(l.placed, 0);
});
t("every placed photo stays inside the margins", () => {
  const sheet = { widthMm: 101.6, heightMm: 152.4 };
  const photo = { widthMm: 50.8, heightMm: 50.8 };
  const l = layoutSheet({ photo, sheet, marginMm: 3, gapMm: 2, copies: 50 });
  for (const p of l.positions) {
    assert.ok(p.x >= 3 - 1e-9 && p.x + photo.widthMm <= sheet.widthMm - 3 + 1e-9);
    assert.ok(p.y >= 3 - 1e-9 && p.y + photo.heightMm <= sheet.heightMm - 3 + 1e-9);
  }
});
t("mm to px at 300 DPI", () => {
  assert.strictEqual(mmToPx(25.4, 300), 300);
  assert.strictEqual(mmToPx(40, 300), 472);
});

console.log("color parsing");
t("hex 6-digit, lowercase, and 3-digit forms", () => {
  assert.strictEqual(parseColor("#1e3a8a"), "#1E3A8A");
  assert.strictEqual(parseColor("abc"), "#AABBCC");
});
t("rgb() and bare comma forms", () => {
  assert.strictEqual(parseColor("rgb(30, 58, 138)"), "#1E3A8A");
  assert.strictEqual(parseColor("30,58,138"), "#1E3A8A");
});
t("rejects invalid input", () => {
  assert.strictEqual(parseColor("#12345"), null);
  assert.strictEqual(parseColor("rgb(300, 0, 0)"), null);
  assert.strictEqual(parseColor("blue"), null);
  assert.strictEqual(parseColor(""), null);
});

console.log("identity warnings");
t("default settings raise no warnings", () => {
  assert.deepStrictEqual(identityWarnings({ intensity: 50, denoise: 40, sharpness: 30 }), []);
});
t("aggressive settings each raise a warning", () => {
  assert.strictEqual(identityWarnings({ intensity: 90, denoise: 40, sharpness: 30 }).length, 1);
  assert.strictEqual(identityWarnings({ intensity: 90, denoise: 90, sharpness: 90 }).length, 3);
});

console.log("undo / redo state machine");
const base = { ...initialState, hydrated: true, edit: DEFAULT_EDIT };
t("a slider drag is one undo step, not one per movement", () => {
  let s = base;
  s = reducer(s, { type: "edit-live", patch: { intensity: 60 } });
  s = reducer(s, { type: "edit-live", patch: { intensity: 70 } });
  s = reducer(s, { type: "edit-live", patch: { intensity: 80 } });
  assert.strictEqual(s.edit.intensity, 80, "live value is applied");
  s = reducer(s, { type: "edit-end" });
  assert.strictEqual(s.history.past.length, 1, "one history entry for the whole drag");
  s = reducer(s, { type: "undo" });
  assert.strictEqual(s.edit.intensity, DEFAULT_EDIT.intensity, "undo restores pre-drag value");
});
t("redo re-applies after undo, and a new edit clears redo", () => {
  let s = base;
  s = reducer(s, { type: "edit-set", patch: { colorGrade: "warm-studio" } });
  s = reducer(s, { type: "undo" });
  assert.strictEqual(s.edit.colorGrade, DEFAULT_EDIT.colorGrade);
  s = reducer(s, { type: "redo" });
  assert.strictEqual(s.edit.colorGrade, "warm-studio");
  s = reducer(s, { type: "undo" });
  s = reducer(s, { type: "edit-set", patch: { cropRatio: "1:1" } });
  assert.strictEqual(s.history.future.length, 0, "new edit discards redo stack");
});
t("undo on empty history is a no-op", () => {
  assert.strictEqual(reducer(base, { type: "undo" }), base);
});
t("reset is undoable", () => {
  let s = reducer(base, { type: "edit-set", patch: { exposure: 40 } });
  s = reducer(s, { type: "reset-edit" });
  assert.strictEqual(s.edit.exposure, 0);
  s = reducer(s, { type: "undo" });
  assert.strictEqual(s.edit.exposure, 40);
});
t("removing the active photo moves selection to the next one", () => {
  const a = { id: "a", name: "a.jpg", mime: "image/jpeg", sizeBytes: 1, width: 1, height: 1, addedAt: "" };
  const b = { ...a, id: "b", name: "b.jpg" };
  let s = { ...base, assets: [a, b], activeAssetId: "a" };
  s = reducer(s, { type: "remove-image", id: "a" });
  assert.strictEqual(s.activeAssetId, "b");
});

console.log(`\n${passed} tests passed`);
