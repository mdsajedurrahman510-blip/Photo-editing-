"use client";

import { useId } from "react";
import { cn } from "@/lib/utils";

interface SliderFieldProps {
  label: string;
  hint?: string;
  value: number;
  min: number;
  max: number;
  step?: number;
  format?: (v: number) => string;
  disabled?: boolean;
  /** Fires on every movement. Use for live preview. */
  onLiveChange: (value: number) => void;
  /** Fires once when the user releases the control. Use for history. */
  onCommit: () => void;
}

/**
 * Slider that separates live updates from committed history steps,
 * so one drag equals one undo step.
 */
export function SliderField({
  label,
  hint,
  value,
  min,
  max,
  step = 1,
  format,
  disabled,
  onLiveChange,
  onCommit,
}: SliderFieldProps) {
  const id = useId();
  const pct = ((value - min) / (max - min)) * 100;
  return (
    <div className="space-y-2">
      <div className="flex items-baseline justify-between gap-3">
        <label htmlFor={id} className="text-sm font-medium text-slate-800">
          {label}
        </label>
        <span className="font-mono text-xs tabular-nums text-slate-500">
          {format ? format(value) : value}
        </span>
      </div>
      <input
        id={id}
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        disabled={disabled}
        onChange={(e) => onLiveChange(Number(e.target.value))}
        onPointerUp={onCommit}
        onKeyUp={onCommit}
        onBlur={onCommit}
        aria-valuetext={format ? format(value) : String(value)}
        className={cn(
          "h-2 w-full cursor-pointer appearance-none rounded-full bg-slate-200 accent-sky-500 disabled:cursor-not-allowed disabled:opacity-50"
        )}
        style={{
          background: `linear-gradient(to right, #0ea5e9 0%, #0ea5e9 ${pct}%, #e2e8f0 ${pct}%, #e2e8f0 100%)`,
        }}
      />
      {hint && <p className="text-xs text-slate-500">{hint}</p>}
    </div>
  );
}
