"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Camera } from "lucide-react";
import { NAV_ITEMS, isActivePath } from "./nav";
import { cn } from "@/lib/utils";
import { useStore } from "@/lib/state/store";

export function AppShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const { state } = useStore();
  const current = NAV_ITEMS.find((n) => isActivePath(pathname, n.href));

  return (
    <div className="min-h-dvh md:flex">
      {/* Desktop sidebar */}
      <aside className="sticky top-0 hidden h-dvh w-64 shrink-0 flex-col border-r border-slate-200 bg-white md:flex">
        <div className="flex items-center gap-3 px-6 py-6">
          <div className="flex size-9 items-center justify-center rounded-xl bg-navy-900 text-white">
            <Camera className="size-5" />
          </div>
          <div>
            <p className="text-sm font-semibold leading-tight text-slate-900">AI Photo Studio</p>
            <p className="text-xs text-slate-500">Pro · Self-hosted</p>
          </div>
        </div>
        <nav aria-label="Main" className="flex-1 space-y-1 overflow-y-auto px-3 pb-4">
          {NAV_ITEMS.map((item) => {
            const active = isActivePath(pathname, item.href);
            const Icon = item.icon;
            return (
              <Link
                key={item.href}
                href={item.href}
                aria-current={active ? "page" : undefined}
                className={cn(
                  "group flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition-colors",
                  active
                    ? "bg-navy-900 text-white shadow-sm"
                    : "text-slate-600 hover:bg-slate-100 hover:text-slate-900"
                )}
              >
                <Icon className="size-4 shrink-0" />
                <span className="truncate">{item.label}</span>
              </Link>
            );
          })}
        </nav>
        <div className="border-t border-slate-200 px-6 py-4 text-xs text-slate-500">
          {state.assets.length} photo{state.assets.length === 1 ? "" : "s"} in workspace
        </div>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        {/* Mobile top bar with scrollable navigation */}
        <header className="sticky top-0 z-30 border-b border-slate-200 bg-white/90 backdrop-blur md:hidden">
          <div className="flex items-center gap-3 px-4 pb-2 pt-[max(env(safe-area-inset-top),0.75rem)]">
            <div className="flex size-8 items-center justify-center rounded-lg bg-navy-900 text-white">
              <Camera className="size-4" />
            </div>
            <p className="min-w-0 truncate text-sm font-semibold text-slate-900">
              {current?.label ?? "AI Photo Studio"}
            </p>
          </div>
          <nav aria-label="Main mobile" className="flex gap-1.5 overflow-x-auto px-3 pb-3 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
            {NAV_ITEMS.map((item) => {
              const active = isActivePath(pathname, item.href);
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  aria-current={active ? "page" : undefined}
                  className={cn(
                    "shrink-0 rounded-full px-3 py-1.5 text-xs font-medium transition-colors",
                    active ? "bg-navy-900 text-white" : "bg-slate-100 text-slate-600"
                  )}
                >
                  {item.label}
                </Link>
              );
            })}
          </nav>
        </header>

        <main className="mx-auto w-full max-w-7xl flex-1 px-4 pb-16 pt-6 sm:px-6 lg:px-8 lg:pt-10">
          {children}
        </main>
      </div>
    </div>
  );
}
