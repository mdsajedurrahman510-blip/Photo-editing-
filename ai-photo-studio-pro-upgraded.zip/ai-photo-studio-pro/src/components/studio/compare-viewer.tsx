"use client";

import { useRef, useState, type PointerEvent } from "react";
import { Maximize2, Minus, Plus, ZoomIn } from "lucide-react";
import { Button } from "@/components/ui/button";

interface CompareViewerProps {
  src: string;
  /** CSS filter applied to the right-hand side as a display-only preview. */
  previewFilter?: string;
  leftLabel?: string;
  rightLabel?: string;
  aspect?: string; // e.g. "4 / 5"
  fit?: "contain" | "cover";
}

const MIN_ZOOM = 1;
const MAX_ZOOM = 4;

/**
 * Before/after slider with zoom and pan. The right side is a CSS-only display
 * preview; it is NOT the AI pipeline output. Labels make that explicit.
 */
export function CompareViewer({
  src,
  previewFilter = "none",
  leftLabel = "Original",
  rightLabel = "Preview",
  aspect = "auto",
  fit = "contain",
}: CompareViewerProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [split, setSplit] = useState(50);
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const drag = useRef<{ mode: "split" | "pan"; startX: number; startY: number; panX: number; panY: number } | null>(null);
  const [panning, setPanning] = useState(false);

  function setSplitFromClientX(clientX: number) {
    const rect = containerRef.current?.getBoundingClientRect();
    if (!rect || rect.width === 0) return;
    const pct = ((clientX - rect.left) / rect.width) * 100;
    setSplit(Math.min(100, Math.max(0, pct)));
  }

  function onPointerDown(e: PointerEvent<HTMLDivElement>) {
    containerRef.current?.setPointerCapture(e.pointerId);
    if (zoom > 1) {
      drag.current = { mode: "pan", startX: e.clientX, startY: e.clientY, panX: pan.x, panY: pan.y };
      setPanning(true);
    } else {
      drag.current = { mode: "split", startX: e.clientX, startY: e.clientY, panX: 0, panY: 0 };
      setSplitFromClientX(e.clientX);
    }
  }

  function onPointerMove(e: PointerEvent<HTMLDivElement>) {
    const d = drag.current;
    if (!d) return;
    if (d.mode === "split") {
      setSplitFromClientX(e.clientX);
    } else {
      setPan({ x: d.panX + (e.clientX - d.startX), y: d.panY + (e.clientY - d.startY) });
    }
  }

  function endDrag(e: PointerEvent<HTMLDivElement>) {
    drag.current = null;
    setPanning(false);
    if (containerRef.current?.hasPointerCapture(e.pointerId)) {
      containerRef.current.releasePointerCapture(e.pointerId);
    }
  }

  function changeZoom(next: number) {
    const clamped = Math.min(MAX_ZOOM, Math.max(MIN_ZOOM, next));
    setZoom(clamped);
    if (clamped === 1) setPan({ x: 0, y: 0 });
  }

  return (
    <div className="space-y-3">
      <div
        ref={containerRef}
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={endDrag}
        onPointerCancel={endDrag}
        className="relative w-full touch-none overflow-hidden rounded-2xl bg-[linear-gradient(45deg,#e2e8f0_25%,transparent_25%),linear-gradient(-45deg,#e2e8f0_25%,transparent_25%),linear-gradient(45deg,transparent_75%,#e2e8f0_75%),linear-gradient(-45deg,transparent_75%,#e2e8f0_75%)] bg-[length:20px_20px] bg-[position:0_0,0_10px,10px_-10px,-10px_0] select-none"
        style={{ aspectRatio: aspect, cursor: zoom > 1 ? (panning ? "grabbing" : "grab") : "ew-resize" }}
        role="group"
        aria-label="Before and after comparison"
      >
        <div
          className="absolute inset-0 origin-center transition-transform duration-150 ease-out"
          style={{ transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})` }}
        >
          {/* Left: original */}
          <img
            src={src}
            alt={`${leftLabel} photo`}
            draggable={false}
            className={`pointer-events-none absolute inset-0 size-full ${fit === "cover" ? "object-cover" : "object-contain"}`}
            style={{ clipPath: `inset(0 ${100 - split}% 0 0)` }}
          />
          {/* Right: display preview */}
          <img
            src={src}
            alt={`${rightLabel} photo`}
            draggable={false}
            className={`pointer-events-none absolute inset-0 size-full ${fit === "cover" ? "object-cover" : "object-contain"}`}
            style={{ clipPath: `inset(0 0 0 ${split}%)`, filter: previewFilter }}
          />
        </div>

        {/* Divider handle */}
        <div
          className="absolute inset-y-0 z-10 w-0.5 bg-white shadow-[0_0_0_1px_rgba(15,23,42,0.15)]"
          style={{ left: `${split}%` }}
          aria-hidden
        >
          <div className="absolute left-1/2 top-1/2 flex size-9 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full bg-white text-slate-700 shadow-md ring-1 ring-slate-900/10">
            <span className="text-[10px] font-bold tracking-tighter">‹ ›</span>
          </div>
        </div>

        <span className="pointer-events-none absolute left-3 top-3 rounded-full bg-black/55 px-2.5 py-1 text-xs font-medium text-white">
          {leftLabel}
        </span>
        <span className="pointer-events-none absolute right-3 top-3 rounded-full bg-black/55 px-2.5 py-1 text-xs font-medium text-white">
          {rightLabel}
        </span>
      </div>

      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-1.5">
          <Button variant="outline" size="icon" aria-label="Zoom out" onClick={() => changeZoom(zoom - 0.5)} disabled={zoom <= MIN_ZOOM}>
            <Minus />
          </Button>
          <span className="w-14 text-center font-mono text-xs tabular-nums text-slate-600">{Math.round(zoom * 100)}%</span>
          <Button variant="outline" size="icon" aria-label="Zoom in" onClick={() => changeZoom(zoom + 0.5)} disabled={zoom >= MAX_ZOOM}>
            <Plus />
          </Button>
          <Button variant="ghost" size="sm" onClick={() => changeZoom(1)} disabled={zoom === 1}>
            <Maximize2 /> Fit
          </Button>
        </div>
        <p className="flex items-center gap-1.5 text-xs text-slate-500">
          <ZoomIn className="size-3.5" />
          {zoom > 1 ? "Drag to pan" : "Drag across the image to compare"}
        </p>
      </div>
    </div>
  );
}
