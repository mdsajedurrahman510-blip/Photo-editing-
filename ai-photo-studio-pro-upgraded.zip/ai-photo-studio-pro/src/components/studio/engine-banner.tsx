"use client";

import { AlertTriangle, CheckCircle2, Loader2, PlugZap, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useEngineStatus } from "@/lib/engine/use-engine-status";
import { cn } from "@/lib/utils";

/** Shows whether the AI processing engine is connected. Never implies results exist when it is not. */
export function EngineBanner({ className }: { className?: string }) {
  const { status, checkedAt, loading, error, refresh } = useEngineStatus();

  const view = (() => {
    if (loading && !status) {
      return { tone: "neutral" as const, icon: Loader2, title: "Checking engine…", body: "Contacting the processing engine." };
    }
    if (error) {
      return { tone: "danger" as const, icon: AlertTriangle, title: "Engine check failed", body: error };
    }
    if (!status || status.state === "not-configured") {
      return {
        tone: "success" as const,
        icon: CheckCircle2,
        title: "On-device photo engine ready",
        body: "Basic non-generative enhancement runs in this browser. Connect the optional Python engine for CPU denoising, face localization, and model-based background segmentation.",
      };
    }
    if (status.state === "not-connected") {
      return {
        tone: "warning" as const,
        icon: AlertTriangle,
        title: "Engine not reachable",
        body: `Could not reach ${status.url}. ${status.error}`,
      };
    }
    return {
      tone: "success" as const,
      icon: CheckCircle2,
      title: "Engine connected",
      body: status.models.length
        ? `Models available: ${status.models.join(", ")}`
        : "Connected, but no models reported yet.",
    };
  })();

  const Icon = view.icon;
  const toneClass = {
    neutral: "border-slate-200 bg-white text-slate-700",
    warning: "border-amber-200 bg-amber-50/70 text-amber-900",
    danger: "border-red-200 bg-red-50/70 text-red-900",
    success: "border-emerald-200 bg-emerald-50/70 text-emerald-900",
  }[view.tone];

  return (
    <div className={cn("flex flex-col gap-3 rounded-2xl border p-4 sm:flex-row sm:items-center sm:justify-between", toneClass, className)}>
      <div className="flex min-w-0 gap-3">
        <Icon className={cn("mt-0.5 size-5 shrink-0", loading && "animate-spin")} />
        <div className="min-w-0">
          <p className="text-sm font-semibold">{view.title}</p>
          <p className="break-anywhere text-sm opacity-80">{view.body}</p>
          {checkedAt && <p className="mt-1 text-xs opacity-60">Checked {new Date(checkedAt).toLocaleTimeString()}</p>}
        </div>
      </div>
      <Button variant="outline" size="sm" onClick={() => void refresh()} disabled={loading} className="shrink-0 bg-white/80">
        <RefreshCw className={cn(loading && "animate-spin")} /> Recheck
      </Button>
    </div>
  );
}

export function EngineBadge() {
  const { status } = useEngineStatus();
  if (!status) return <Badge tone="neutral">Checking…</Badge>;
  if (status.state === "connected") return <Badge tone="success">Python engine connected</Badge>;
  if (status.state === "not-connected") return <Badge tone="warning">Engine unreachable</Badge>;
  return <Badge tone="success">On-device engine ready</Badge>;
}
