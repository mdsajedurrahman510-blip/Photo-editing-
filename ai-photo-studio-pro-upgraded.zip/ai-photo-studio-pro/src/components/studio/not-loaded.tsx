import { RotateCcw } from "lucide-react";

/** Shown when metadata exists from an earlier session but the file itself is gone. */
export function NotLoadedNotice({ what }: { what: string }) {
  return (
    <div className="flex flex-col items-start gap-2 rounded-2xl border border-dashed border-slate-300 bg-white p-6 text-sm text-slate-600 sm:flex-row sm:items-center">
      <RotateCcw className="size-4 shrink-0 text-slate-400" />
      <p>
        The {what} was added in an earlier session. Files are kept only in this browser tab, so please re-upload it to view or process it.
      </p>
    </div>
  );
}
