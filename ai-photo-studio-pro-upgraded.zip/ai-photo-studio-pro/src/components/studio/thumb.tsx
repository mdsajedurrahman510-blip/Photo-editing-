import { ImageOff } from "lucide-react";
import { getFileUrl } from "@/lib/state/file-registry";
import { cn } from "@/lib/utils";

/** Thumbnail from the in-session file registry. Shows a placeholder after a reload. */
export function Thumb({ id, alt, className }: { id: string; alt: string; className?: string }) {
  const url = getFileUrl(id);
  if (!url) {
    return (
      <div className={cn("flex items-center justify-center bg-slate-100 text-slate-400", className)} aria-label="File not loaded in this session">
        <ImageOff className="size-5" />
      </div>
    );
  }
  // eslint-disable-next-line @next/next/no-img-element
  return <img src={url} alt={alt} className={cn("object-cover", className)} draggable={false} />;
}
