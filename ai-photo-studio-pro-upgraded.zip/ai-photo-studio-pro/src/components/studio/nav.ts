import { Download, IdCard, Layers, LayoutDashboard, ListOrdered, Settings, Shirt, SlidersHorizontal, Sparkles, Users, type LucideIcon } from "lucide-react";
export interface NavItem { href: string; label: string; icon: LucideIcon; description: string }
export const NAV_ITEMS: NavItem[] = [
  { href: "/", label: "Dashboard", icon: LayoutDashboard, description: "Overview and quick start" },
  { href: "/editor", label: "Photo Editor", icon: SlidersHorizontal, description: "Enhance and export photos" },
  { href: "/enhance", label: "AI Enhancement", icon: Sparkles, description: "Natural photo finishing" },
  { href: "/background", label: "Background Studio", icon: Layers, description: "Choose studio backgrounds" },
  { href: "/passport", label: "Passport Studio", icon: IdCard, description: "Exact-size print sheets" },
  { href: "/paired", label: "Paired Photo", icon: Users, description: "Two-person portrait layouts" },
  { href: "/clothing", label: "Clothing Studio", icon: Shirt, description: "Clothing enhancement guidance" },
  { href: "/batch", label: "Batch Processing", icon: ListOrdered, description: "Process multiple photographs" },
  { href: "/export", label: "Export Center", icon: Download, description: "Export settings" },
  { href: "/settings", label: "Settings", icon: Settings, description: "Preferences and data" },
];
export function isActivePath(pathname: string, href: string): boolean {
  if (href === "/") return pathname === "/";
  return pathname === href || pathname.startsWith(`${href}/`);
}
