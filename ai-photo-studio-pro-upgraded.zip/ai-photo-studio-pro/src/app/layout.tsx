import type { Metadata, Viewport } from "next";
import "./globals.css";
import { StoreProvider } from "@/lib/state/store";
import { AppShell } from "@/components/studio/app-shell";

export const metadata: Metadata = {
  title: {
    default: "AI Photo Studio Pro",
    template: "%s · AI Photo Studio Pro",
  },
  description: "Professional photo finishing, paired portraits and exact-size passport print layouts.",
  manifest: "/manifest.webmanifest",
  icons: { icon: "/icon.svg", apple: "/icon.svg" },
  applicationName: "AI Photo Studio Pro",
  appleWebApp: { capable: true, title: "Photo Studio", statusBarStyle: "default" },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
  themeColor: "#142b4a",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="h-full antialiased">
      <body className="min-h-full">
        <StoreProvider>
          <AppShell>{children}</AppShell>
        </StoreProvider>
      </body>
    </html>
  );
}
