"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { Download, IdCard, LoaderCircle, Plus, Minus, ImagePlus } from "lucide-react";
import { PageHeader } from "@/components/studio/page-header";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useStore } from "@/lib/state/store";
import { getFile, getFileUrl, getProcessedFile, getProcessedFileUrl } from "@/lib/state/file-registry";
import { PHOTO_SIZES, SHEET_SIZES } from "@/lib/config/passport";
import { BACKGROUND_PRESETS } from "@/lib/config/backgrounds";
import { renderPrintSheet, downloadBlob, jpegToPdf } from "@/lib/image/browser-engine";

export default function PassportPage() {
  const { state } = useStore();
  const active = useMemo(() => state.assets.find((a) => a.id === state.activeAssetId) ?? state.assets[0] ?? null, [state.assets, state.activeAssetId]);
  const [sizeId, setSizeId] = useState("40x50");
  const [customW, setCustomW] = useState(40);
  const [customH, setCustomH] = useState(50);
  const [sheetId, setSheetId] = useState("4x6in");
  const [copies, setCopies] = useState(6);
  const [margin, setMargin] = useState(3);
  const [gap, setGap] = useState(2);
  const [dpi, setDpi] = useState(300);
  const [background, setBackground] = useState("#FFFFFF");
  const [format, setFormat] = useState<"jpg" | "pdf">("jpg");
  const [output, setOutput] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);
  useEffect(() => () => { if (output) URL.revokeObjectURL(output); }, [output]);

  const photoPreset = PHOTO_SIZES.find((s) => s.id === sizeId);
  const photoW = sizeId === "custom" ? customW : photoPreset?.widthMm ?? 40;
  const photoH = sizeId === "custom" ? customH : photoPreset?.heightMm ?? 50;
  const sheet = SHEET_SIZES.find((s) => s.id === sheetId) ?? SHEET_SIZES[0];
  const px = { w: Math.round(photoW / 25.4 * dpi), h: Math.round(photoH / 25.4 * dpi) };
  const sheetPx = { w: Math.round(sheet.widthMm / 25.4 * dpi), h: Math.round(sheet.heightMm / 25.4 * dpi) };
  const cols = Math.max(0, Math.floor((sheet.widthMm - 2 * margin + gap) / (photoW + gap)));
  const rows = Math.max(0, Math.floor((sheet.heightMm - 2 * margin + gap) / (photoH + gap)));
  const capacity = cols * rows;
  const placed = Math.min(copies, capacity);

  async function exportSheet() {
    if (!active) { setNotice("Upload a single-person photo in Photo Editor first."); return; }
    const file = getProcessedFile(active.id) ?? getFile(active.id); if (!file) { setNotice("Please upload the photo again; original files are held in this browser session only."); return; }
    setBusy(true); setNotice(null);
    try {
      const blob = await renderPrintSheet(file, photoW, photoH, sheet.widthMm, sheet.heightMm, copies, margin, gap, dpi, background);
      const url = URL.createObjectURL(blob); setOutput((old) => { if (old) URL.revokeObjectURL(old); return url; });
      setNotice("Print sheet created. Pixel dimensions are based on the selected millimetres and DPI.");
    } catch (error) { setNotice(error instanceof Error ? error.message : "Could not create print sheet."); }
    finally { setBusy(false); }
  }

  async function downloadSheet() {
    if (!output) return;
    const blob = await fetch(output).then((r) => r.blob());
    if (format === "pdf") {
      const pdf = await jpegToPdf(blob, sheet.widthMm, sheet.heightMm);
      downloadBlob(pdf, `passport-sheet-${sheet.widthMm}x${sheet.heightMm}mm-${dpi}dpi.pdf`);
    } else {
      downloadBlob(blob, `passport-sheet-${sheet.widthMm}x${sheet.heightMm}mm-${dpi}dpi.jpg`);
    }
  }

  return <div className="space-y-6">
    <PageHeader title="Passport & ID Photo Studio" description="Create print sheets with true millimetre-to-pixel geometry and high-resolution JPG output." actions={<Badge tone="success"><IdCard className="mr-1 size-3"/> 300 DPI ready</Badge>}/>
    {notice && <div role="status" className="rounded-xl border border-sky-200 bg-sky-50 px-4 py-3 text-sm text-sky-900">{notice}</div>}
    <div className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_370px]">
      <div className="space-y-5">
        <Card><CardHeader><CardTitle>Source photograph</CardTitle><CardDescription>{active ? `${active.name} · ${active.width} × ${active.height} px` : "Upload a single-person photo in the editor."}</CardDescription></CardHeader><CardContent>{active && (getProcessedFileUrl(active.id) ?? getFileUrl(active.id)) ? <img src={(getProcessedFileUrl(active.id) ?? getFileUrl(active.id))!} alt="Passport photo source" className="mx-auto max-h-[420px] w-full rounded-xl bg-slate-100 object-contain"/> : <div className="rounded-xl bg-slate-50 p-8 text-center text-sm text-slate-500"><ImagePlus className="mx-auto mb-2 size-7"/>No photo available. <Link href="/editor" className="font-medium text-sky-700">Upload in Photo Editor</Link>.</div>}</CardContent></Card>
        <Card><CardHeader className="flex-row items-center justify-between"><div><CardTitle>Print sheet preview</CardTitle><CardDescription>{placed} of {copies} copies fit · {cols} columns × {rows} rows</CardDescription></div>{output && <Badge tone="success">Ready</Badge>}</CardHeader><CardContent className="space-y-4">
          {output ? <img src={output} alt="Generated passport print sheet" className="mx-auto max-h-[620px] w-full rounded-xl border bg-slate-100 object-contain"/> : <div className="mx-auto max-w-md rounded-xl border bg-slate-50 p-5"><div className="grid gap-1" style={{ gridTemplateColumns: `repeat(${Math.max(cols, 1)}, minmax(0, 1fr))` }}>{Array.from({ length: placed }, (_, i) => <div key={i} className="overflow-hidden border border-dashed border-sky-500 bg-white" style={{ aspectRatio: `${photoW}/${photoH}` }}>{active && (getProcessedFileUrl(active.id) ?? getFileUrl(active.id)) && <img src={(getProcessedFileUrl(active.id) ?? getFileUrl(active.id))!} alt="Layout thumbnail" className="size-full object-cover"/>}</div>)}</div></div>}
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">{[["Photo size", `${photoW} × ${photoH} mm`],["Photo pixels", `${px.w} × ${px.h}`],["Sheet pixels", `${sheetPx.w} × ${sheetPx.h}`],["Capacity", `${capacity} photos`]].map(([label, value]) => <div key={label} className="rounded-lg bg-slate-50 p-3"><p className="text-[10px] uppercase text-slate-500">{label}</p><p className="mt-1 break-words font-mono text-xs">{value}</p></div>)}</div>
          {output && <div className="grid grid-cols-[100px_1fr] gap-2"><select value={format} onChange={(e) => setFormat(e.target.value as "jpg" | "pdf")} className="h-10 rounded-xl border bg-white px-2 text-sm"><option value="jpg">JPG</option><option value="pdf">PDF</option></select><Button onClick={() => void downloadSheet()}><Download/> Download print sheet</Button></div>}
        </CardContent></Card>
      </div>
      <aside className="space-y-5">
        <Card><CardHeader><CardTitle>Individual photo dimensions</CardTitle><CardDescription>This is the size of each single-person photo.</CardDescription></CardHeader><CardContent className="space-y-3"><div className="grid grid-cols-2 gap-2">{PHOTO_SIZES.map((s) => <button key={s.id} onClick={() => setSizeId(s.id)} className={`rounded-xl border p-3 text-left text-sm ${sizeId === s.id ? "border-sky-500 bg-sky-50 text-sky-900" : "bg-white"}`}>{s.name}</button>)}<button onClick={() => setSizeId("custom")} className={`rounded-xl border p-3 text-left text-sm ${sizeId === "custom" ? "border-sky-500 bg-sky-50 text-sky-900" : "bg-white"}`}>Custom size</button></div>{sizeId === "custom" && <div className="grid grid-cols-2 gap-2"><Num label="Width mm" value={customW} onChange={setCustomW}/><Num label="Height mm" value={customH} onChange={setCustomH}/></div>}</CardContent></Card>
        <Card><CardHeader><CardTitle>Print sheet settings</CardTitle></CardHeader><CardContent className="space-y-3"><Select label="Paper" value={sheetId} onChange={setSheetId} options={SHEET_SIZES.map((s) => [s.id, s.name])}/><div className="flex items-center justify-between"><span className="text-sm">Copies</span><div className="flex items-center gap-2"><Button size="icon" variant="outline" onClick={() => setCopies(Math.max(1, copies - 1))}><Minus/></Button><strong className="w-6 text-center">{copies}</strong><Button size="icon" variant="outline" onClick={() => setCopies(Math.min(99, copies + 1))}><Plus/></Button></div></div><div className="grid grid-cols-2 gap-2"><Num label="Margin mm" value={margin} onChange={setMargin}/><Num label="Gap mm" value={gap} onChange={setGap}/></div><Select label="Print DPI" value={String(dpi)} onChange={(v) => setDpi(Number(v))} options={[["150", "150 DPI"],["300", "300 DPI"],["600", "600 DPI"]]}/><label className="block text-xs font-medium text-slate-700">Paper background</label><div className="flex items-center gap-2"><input type="color" value={background} onChange={(e) => setBackground(e.target.value)} className="size-10 rounded border p-1"/><input value={background} onChange={(e) => setBackground(e.target.value)} className="h-10 min-w-0 flex-1 rounded border px-2 font-mono text-sm"/></div><div className="grid grid-cols-7 gap-2">{BACKGROUND_PRESETS.map((p) => <button key={p.id} title={p.name} onClick={() => setBackground(p.hex)} className="aspect-square rounded-md border" style={{ backgroundColor: p.hex }}/>)}</div><Button className="w-full" disabled={busy || !active || !placed} onClick={() => void exportSheet()}>{busy ? <LoaderCircle className="animate-spin"/> : <Download/>} Create print sheet</Button></CardContent></Card>
        <Card><CardContent className="p-4 text-xs leading-relaxed text-slate-600">Important: physical dimensions and DPI are encoded through pixel geometry. The JPEG file itself does not guarantee a printer honours the intended physical size; choose 100% / actual size in your print dialog. Passport rules vary by country. For a two-person paired portrait, use <Link href="/paired" className="font-medium text-sky-700">Paired Photo Studio</Link>; this individual passport tool is not for two people in one crop.</CardContent></Card>
      </aside>
    </div>
  </div>;
}
function Num({ label, value, onChange }: { label: string; value: number; onChange: (v: number) => void }) { return <label className="block space-y-1"><span className="text-xs font-medium text-slate-600">{label}</span><input type="number" min={0} max={300} value={value} onChange={(e) => onChange(Math.max(0, Math.min(300, Number(e.target.value) || 0)))} className="h-10 w-full rounded-lg border px-2 text-sm"/></label>; }
function Select({ label, value, onChange, options }: { label: string; value: string; onChange: (v: string) => void; options: [string, string][] }) { return <label className="block space-y-1"><span className="text-xs font-medium text-slate-600">{label}</span><select value={value} onChange={(e) => onChange(e.target.value)} className="h-10 w-full rounded-lg border bg-white px-3 text-sm">{options.map(([v, labelText]) => <option key={v} value={v}>{labelText}</option>)}</select></label>; }
