"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import { Download, ImagePlus, LoaderCircle, Users } from "lucide-react";
import { PageHeader } from "@/components/studio/page-header";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useStore } from "@/lib/state/store";
import { getFile, getFileUrl, registerFile, getProcessedFile, getProcessedFileUrl } from "@/lib/state/file-registry";
import { readImageMeta } from "@/lib/image/read-meta";
import { validateImage } from "@/lib/upload-rules";
import { newId } from "@/lib/utils";
import { BACKGROUND_PRESETS } from "@/lib/config/backgrounds";
import { downloadBlob, renderPairedPortrait, jpegToPdf } from "@/lib/image/browser-engine";
import type { ImageAsset } from "@/lib/state/types";

export default function PairedPhotoPage() {
  const { state, dispatch } = useStore();
  const [selectedId, setSelectedId] = useState<string | null>(state.activeAssetId);
  const [width, setWidth] = useState(60);
  const [height, setHeight] = useState(45);
  const [dpi, setDpi] = useState(300);
  const [background, setBackground] = useState("#00A8E8");
  const [output, setOutput] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);
  const [fit, setFit] = useState<"contain" | "cover">("contain");
  const [format, setFormat] = useState<"jpg" | "pdf">("jpg");
  const asset = useMemo(() => state.assets.find((a) => a.id === selectedId) ?? state.assets.find((a) => a.id === state.activeAssetId) ?? null, [state.assets, selectedId, state.activeAssetId]);
  const sourceUrl = asset ? (getProcessedFileUrl(asset.id) ?? getFileUrl(asset.id)) : null;

  async function upload(files: FileList | null) {
    if (!files?.length) return;
    const file = files[0]; const validation = validateImage(file);
    if (!validation.ok) { setNotice(validation.error ?? "Unsupported image."); return; }
    try {
      const meta = await readImageMeta(file); const id = newId(); registerFile(id, file);
      const next: ImageAsset = { id, name: file.name, mime: file.type, sizeBytes: file.size, width: meta.width, height: meta.height, addedAt: new Date().toISOString() };
      dispatch({ type: "add-image", asset: next }); dispatch({ type: "set-active", id }); setSelectedId(id); setOutput(null); setNotice("Paired portrait source added. Make sure both people are visible in this original frame.");
    } catch (error) { setNotice(error instanceof Error ? error.message : "Could not read this photo."); }
  }

  async function makePaired() {
    if (!asset) return;
    const file = getProcessedFile(asset.id) ?? getFile(asset.id); if (!file) { setNotice("Please upload this photo again."); return; }
    setBusy(true); setNotice(null);
    try {
      const blob = await renderPairedPortrait(file, width, height, dpi, background, fit);
      const url = URL.createObjectURL(blob); if (output) URL.revokeObjectURL(output); setOutput(url);
      setNotice("Paired portrait created with exact canvas pixel dimensions. The entire source frame was retained.");
    } catch (error) { setNotice(error instanceof Error ? error.message : "Could not create paired portrait."); }
    finally { setBusy(false); }
  }

  async function download() {
    if (!output) return;
    const blob = await fetch(output).then((r) => r.blob());
    if (format === "pdf") downloadBlob(await jpegToPdf(blob, width, height), `paired-photo-${width}x${height}mm-${dpi}dpi.pdf`);
    else downloadBlob(blob, `paired-photo-${width}x${height}mm-${dpi}dpi.jpg`);
  }

  return <div className="space-y-6">
    <PageHeader title="Two-Person Paired Photo Studio" description="Create a correctly sized portrait canvas while keeping both people together in the original frame." actions={<Badge tone="info"><Users className="mr-1 size-3"/> Paired mode</Badge>}/>
    {notice && <div role="status" className="rounded-xl border border-sky-200 bg-sky-50 px-4 py-3 text-sm text-sky-900">{notice}</div>}
    <div className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_350px]">
      <div className="space-y-5">
        {!asset ? <label className="flex min-h-64 cursor-pointer flex-col items-center justify-center rounded-3xl border-2 border-dashed border-slate-300 bg-white p-8 text-center"><ImagePlus className="size-10 text-sky-600"/><strong className="mt-3">Upload one photo containing two people</strong><span className="mt-1 text-xs text-slate-500">This mode retains the complete two-person frame.</span><input className="sr-only" type="file" accept="image/jpeg,image/png,image/webp" onChange={(e) => void upload(e.target.files)}/></label> : <Card><CardHeader><CardTitle>Original paired photo</CardTitle><CardDescription>{asset.name} · {asset.width} × {asset.height} px</CardDescription></CardHeader><CardContent>{sourceUrl && <img src={sourceUrl} alt="Original paired portrait" className="mx-auto max-h-[560px] w-full rounded-xl bg-slate-100 object-contain"/>}</CardContent></Card>}
        {output && <Card><CardHeader className="flex-row items-center justify-between"><div><CardTitle>Paired print preview</CardTitle><CardDescription>{width} × {height} mm · {Math.round(width / 25.4 * dpi)} × {Math.round(height / 25.4 * dpi)} px · {dpi} DPI</CardDescription></div><Badge tone="success">Ready</Badge></CardHeader><CardContent><img src={output} alt="Paired portrait print preview" className="mx-auto max-h-[520px] rounded-xl border bg-white object-contain"/><div className="mt-4 grid grid-cols-[100px_1fr] gap-2"><select value={format} onChange={(e) => setFormat(e.target.value as "jpg" | "pdf")} className="h-10 rounded-xl border bg-white px-2 text-sm"><option value="jpg">JPG</option><option value="pdf">PDF</option></select><Button onClick={() => void download()}><Download/> Download paired photo</Button></div></CardContent></Card>}
      </div>
      <aside className="space-y-5">
        <Card><CardHeader><CardTitle>Paired canvas size</CardTitle><CardDescription>The dimensions apply to the complete two-person image, not each person individually.</CardDescription></CardHeader><CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-3"><NumberField label="Width (mm)" value={width} onChange={setWidth}/><NumberField label="Height (mm)" value={height} onChange={setHeight}/></div>
          <div><label className="mb-1 block text-xs font-medium text-slate-700">Print resolution</label><select value={dpi} onChange={(e) => setDpi(Number(e.target.value))} className="h-10 w-full rounded-lg border bg-white px-3 text-sm"><option value={150}>150 DPI</option><option value={300}>300 DPI (recommended)</option><option value={600}>600 DPI</option></select></div>
          <div><label className="mb-1 block text-xs font-medium text-slate-700">Fit source photo</label><select value={fit} onChange={(e) => setFit(e.target.value as "contain" | "cover")} className="h-10 w-full rounded-lg border bg-white px-3 text-sm"><option value="contain">Contain — keep both people, may add margins</option><option value="cover">Cover — fill canvas, may crop edges</option></select></div>
          <div><label className="mb-1 block text-xs font-medium text-slate-700">Background / canvas color</label><div className="flex gap-2"><input type="color" value={background} onChange={(e) => setBackground(e.target.value)} className="size-10 rounded-lg border bg-white p-1"/><input value={background.toUpperCase()} onChange={(e) => setBackground(e.target.value)} className="h-10 min-w-0 flex-1 rounded-lg border px-3 font-mono text-sm"/></div><div className="mt-3 grid grid-cols-7 gap-2">{BACKGROUND_PRESETS.map((p) => <button key={p.id} title={p.name} onClick={() => setBackground(p.hex)} className="aspect-square rounded-md border" style={{ backgroundColor: p.hex }}/>)}</div></div>
          <Button className="w-full" disabled={!asset || busy} onClick={() => void makePaired()}>{busy ? <LoaderCircle className="animate-spin"/> : <Users/>} Create paired photo</Button>
          <p className="text-[11px] leading-relaxed text-slate-500">This tool resizes the full source frame to the specified physical canvas. It does not detect or reconstruct people, and it is not an official individual passport format.</p>
        </CardContent></Card>
        <Card><CardContent className="space-y-2 p-4"><p className="text-sm font-semibold">Need two separate passport photos?</p><p className="text-xs text-slate-500">Use Passport Studio for a single-person photo. A pair source should be face-localized and crop-checked before producing two individual passport photos.</p><Link href="/passport" className="text-sm font-medium text-sky-700">Open Passport Studio →</Link></CardContent></Card>
      </aside>
    </div>
  </div>;
}
function NumberField({ label, value, onChange }: { label: string; value: number; onChange: (v: number) => void }) { return <label className="block space-y-1"><span className="text-xs font-medium text-slate-700">{label}</span><input type="number" min={10} max={300} value={value} onChange={(e) => onChange(Math.max(10, Math.min(300, Number(e.target.value) || 10)))} className="h-10 w-full rounded-lg border px-3 text-sm"/></label>; }
