import { NextResponse } from "next/server";
import type { EngineHealthResponse, EngineStatus } from "@/lib/engine/types";

export const dynamic = "force-dynamic";

const TIMEOUT_MS = 3000;

/**
 * Reports whether the AI engine configured via PHOTO_ENGINE_URL is reachable.
 * The URL comes only from server environment, never from the request, so this
 * route cannot be used to probe arbitrary hosts.
 */
export async function GET() {
  const checkedAt = new Date().toISOString();
  const base = process.env.PHOTO_ENGINE_URL?.replace(/\/+$/, "");

  if (!base) {
    const body: EngineHealthResponse = { status: { state: "not-configured" }, checkedAt };
    return NextResponse.json(body);
  }

  let status: EngineStatus;
  try {
    const res = await fetch(`${base}/health`, {
      cache: "no-store",
      signal: AbortSignal.timeout(TIMEOUT_MS),
    });
    if (!res.ok) throw new Error(`Engine responded with HTTP ${res.status}`);
    const json = (await res.json()) as { version?: unknown; models?: unknown };
    status = {
      state: "connected",
      url: base,
      version: typeof json.version === "string" ? json.version : undefined,
      models: Array.isArray(json.models) ? json.models.filter((m): m is string => typeof m === "string") : [],
    };
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unknown error";
    status = { state: "not-connected", url: base, error: message };
  }

  const body: EngineHealthResponse = { status, checkedAt };
  return NextResponse.json(body);
}
