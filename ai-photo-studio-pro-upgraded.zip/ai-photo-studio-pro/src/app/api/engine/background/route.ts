import { NextResponse } from "next/server";

export const runtime = "nodejs";
export const maxDuration = 60;

export async function POST(request: Request) {
  const base = process.env.PHOTO_ENGINE_URL?.replace(/\/+$/, "");
  if (!base) return NextResponse.json({ error: "Background removal requires a connected engine with the optional rembg model installed." }, { status: 503 });
  const incoming = await request.formData();
  const file = incoming.get("image");
  const color = String(incoming.get("color") ?? "#00A8E8");
  if (!(file instanceof File)) return NextResponse.json({ error: "An image file is required." }, { status: 400 });
  const body = new FormData(); body.append("image", file, file.name); body.append("color", color);
  try {
    const response = await fetch(`${base}/remove-background`, { method: "POST", body, signal: AbortSignal.timeout(55_000) });
    if (!response.ok) return NextResponse.json({ error: await response.text() || `Engine returned HTTP ${response.status}.` }, { status: response.status });
    return new Response(await response.arrayBuffer(), { headers: { "Content-Type": response.headers.get("content-type") ?? "image/jpeg", "Cache-Control": "no-store" } });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "Background removal failed." }, { status: 502 });
  }
}
