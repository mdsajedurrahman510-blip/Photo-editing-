import { NextResponse } from "next/server";

export const runtime = "nodejs";
export const maxDuration = 60;

export async function POST(request: Request) {
  const base = process.env.PHOTO_ENGINE_URL?.replace(/\/+$/, "");
  if (!base) return NextResponse.json({ error: "No PHOTO_ENGINE_URL configured." }, { status: 503 });
  const incoming = await request.formData();
  const file = incoming.get("image");
  const settings = incoming.get("settings") ?? "{}";
  if (!(file instanceof File)) return NextResponse.json({ error: "An image file is required." }, { status: 400 });
  const body = new FormData();
  body.append("image", file, file.name);
  body.append("settings", String(settings));
  try {
    const response = await fetch(`${base}/process`, { method: "POST", body, signal: AbortSignal.timeout(55_000) });
    if (!response.ok) {
      const detail = await response.text();
      return NextResponse.json({ error: detail || `Processing engine returned HTTP ${response.status}.` }, { status: response.status });
    }
    const bytes = await response.arrayBuffer();
    return new Response(bytes, {
      status: 200,
      headers: {
        "Content-Type": response.headers.get("content-type") ?? "image/jpeg",
        "X-Processing-Engine": response.headers.get("x-processing-engine") ?? "Connected photo engine",
        "X-Photo-Metadata": response.headers.get("x-photo-metadata") ?? "{}",
        "Cache-Control": "no-store",
      },
    });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "Processing engine request failed." }, { status: 502 });
  }
}
