import { NextResponse } from "next/server";

export const runtime = "nodejs";
export async function POST(request: Request) {
  const base = process.env.PHOTO_ENGINE_URL?.replace(/\/+$/, "");
  if (!base) return NextResponse.json({ error: "Face localization requires a connected Python engine." }, { status: 503 });
  const incoming = await request.formData(); const file = incoming.get("image");
  if (!(file instanceof File)) return NextResponse.json({ error: "An image file is required." }, { status: 400 });
  const body = new FormData(); body.append("image", file, file.name);
  try {
    const response = await fetch(`${base}/detect-faces`, { method: "POST", body, signal: AbortSignal.timeout(20_000) });
    return NextResponse.json(await response.json(), { status: response.status });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "Face localization failed." }, { status: 502 });
  }
}
