"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { Archive, Download, ImagePlus, LoaderCircle, Play, Trash2 } from "lucide-react";
import { PageHeader } from "@/components/studio/page-header";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useStore } from "@/lib/state/store";
import { getFile, getFileUrl, registerFile, releaseFile } from "@/lib/state/file-registry";
import { readImageMeta } from "@/lib/image/read-meta";
import { validateImage } from "@/lib/upload-rules";
import { newId, formatBytes } from "@/lib/utils";
import { enhanceImageInBrowser } from "@/lib/image/browser-engine";
import { createZip } from "@/lib/image/zip";
import { downloadBlob } from "@/lib/image/browser-engine";
import type { ImageAsset } from "@/lib/state/types";

interface Result { assetId: string; name: string; blob: Blob; url: string }

export default function BatchPage() {
  const { state, dispatch } = useStore();
  const [busy, setBusy] = useState(false);
  const [progress, setProgress] = useState(0);
  const [notice, setNotice] = useState<string | null>(null);
  const [results, setResults] = useState<Result[]>([]);
  const [failed, setFailed] = useState<string[]>([]);
  useEffect(() => () => results.forEach((r) => URL.revokeObjectURL(r.url)), [results]);

  async function addFiles(files: FileList | File[]) {
    setNotice(null);
    for (const file of Array.from(files).slice(0, 30)) {
      const check = validateImage(file);
      if (!check.ok) { setNotice(check.error ?? "Unsupported image."); continue; }
      try {
        const meta = await readImageMeta(file); const id = newId(); registerFile(id, file);
        const asset: ImageAsset = { id, name: file.name, mime: file.type, sizeBytes: file.size, width: meta.width, height: meta.height, addedAt: new Date().toISOString() };
        dispatch({ type: "add-image", asset });
      } catch (error) { setNotice(error instanceof Error ? error.message : `Could not read ${file.name}.`); }
    }
  }

  async function processAll() {
    const queue = state.assets.filter((asset) => getFile(asset.id));
    if (!queue.length) { setNotice("Upload photos before starting batch processing. Files must still be present in this browser session."); return; }
    setBusy(true); setProgress(0); setFailed([]); setNotice(null);
    const completed: Result[] = [];
    const failedNames: string[] = [];
    for (let index = 0; index < queue.length; index++) {
      const asset = queue[index]; const file = getFile(asset.id);
      if (!file) { failedNames.push(asset.name); setProgress(Math.round(((index + 1) / queue.length) * 100)); continue; }
      try {
        const enhanced = await enhanceImageInBrowser(file, { autoLight: true, brightness: 0, contrast: 6, denoise: 22, sharpness: 24, faceLight: 18 });
        completed.push({ assetId: asset.id, name: asset.name, blob: enhanced.blob, url: URL.createObjectURL(enhanced.blob) });
      } catch {
        failedNames.push(asset.name);
      }
      setProgress(Math.round(((index + 1) / queue.length) * 100));
      // Yield to the UI so progress remains visible on mobile devices.
      await new Promise((resolve) => window.setTimeout(resolve, 20));
    }
    setResults((old) => { old.forEach((r) => URL.revokeObjectURL(r.url)); return completed; });
    setFailed(failedNames);
    setBusy(false);
    setNotice(`${completed.length} of ${queue.length} photos processed on this device.${failedNames.length ? ` ${failedNames.length} photo(s) could not be processed.` : ""}`);
  }

  async function downloadAll() {
    if (!results.length) return;
    const zip = await createZip(results.map((r) => ({ name: `${r.name.replace(/\.[^.]+$/, "")}-enhanced.jpg`, blob: r.blob })));
    downloadBlob(zip, "ai-photo-studio-batch-results.zip");
  }

  function clearPhotos() {
    state.assets.forEach((a) => releaseFile(a.id));
    dispatch({ type: "clear-all" });
    results.forEach((r) => URL.revokeObjectURL(r.url));
    setResults([]); setFailed([]); setProgress(0); setNotice("Workspace cleared.");
  }

  return <div className="space-y-6">
    <PageHeader title="Batch Photo Processing" description="Process multiple photographs sequentially on your device, without paid APIs or a GPU server." actions={<Badge tone="success">Local processing</Badge>}/>
    {notice && <div role="status" className="rounded-xl border border-sky-200 bg-sky-50 px-4 py-3 text-sm text-sky-900">{notice}</div>}
    <Card><CardHeader><CardTitle>Upload photographs</CardTitle><CardDescription>Select up to 30 files. For mobile stability, images are processed one at a time.</CardDescription></CardHeader><CardContent><label className="flex cursor-pointer flex-col items-center justify-center rounded-2xl border-2 border-dashed border-slate-300 bg-slate-50 p-8 text-center hover:border-sky-400"><ImagePlus className="size-8 text-sky-600"/><strong className="mt-2 text-sm">Choose multiple photos</strong><span className="mt-1 text-xs text-slate-500">JPG, PNG or WebP · up to 50 MB each</span><input className="sr-only" type="file" accept="image/jpeg,image/png,image/webp" multiple onChange={(e) => { if (e.target.files) void addFiles(e.target.files); e.currentTarget.value = ""; }}/></label></CardContent></Card>
    <Card><CardHeader className="flex-row items-center justify-between"><div><CardTitle>Processing queue</CardTitle><CardDescription>{state.assets.length} photos in current workspace · {results.length} completed</CardDescription></div><div className="flex gap-2"><Button variant="outline" size="sm" onClick={clearPhotos} disabled={busy || !state.assets.length}><Trash2/> Clear</Button><Button size="sm" onClick={() => void processAll()} disabled={busy || !state.assets.length}>{busy ? <LoaderCircle className="animate-spin"/> : <Play/>} {busy ? "Processing" : "Process all"}</Button></div></CardHeader><CardContent className="space-y-4">
      {busy && <div><div className="mb-1 flex justify-between text-xs"><span>Processing sequentially</span><span className="font-mono">{progress}%</span></div><div className="h-2 overflow-hidden rounded-full bg-slate-100"><div className="h-full rounded-full bg-sky-600 transition-all" style={{ width: `${progress}%` }}/></div></div>}
      {!state.assets.length ? <p className="rounded-xl bg-slate-50 p-8 text-center text-sm text-slate-500">No photos yet. Add images above to build your batch.</p> : <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">{state.assets.map((asset) => { const done = results.find((r) => r.assetId === asset.id); return <div key={asset.id} className="overflow-hidden rounded-xl border bg-white"><img src={done?.url ?? getFileUrl(asset.id) ?? ""} alt={asset.name} className="aspect-[4/5] w-full bg-slate-100 object-cover"/><div className="space-y-1 p-2"><p className="truncate text-xs font-medium">{asset.name}</p><p className="text-[10px] text-slate-500">{asset.width} × {asset.height} · {formatBytes(asset.sizeBytes)}</p><Badge tone={done ? "success" : "neutral"}>{done ? "Completed" : "Queued"}</Badge></div></div>; })}</div>}
      {results.length > 0 && <Button className="w-full" onClick={() => void downloadAll()}><Archive/> Download all completed photos (ZIP)</Button>}
      {failed.length > 0 && <div className="rounded-xl border border-amber-200 bg-amber-50 p-3 text-xs text-amber-900">Could not process: {failed.join(", ")}</div>}
    </CardContent></Card>
    <p className="text-xs text-slate-500">The built-in batch pipeline is non-generative local photo finishing. It does not perform learned AI face restoration, background segmentation, or clothing replacement. Use the main editor to connect an optional Python engine for server-side processing.</p>
    <p className="text-xs text-slate-500">Need paired portrait canvas sizing? <Link href="/paired" className="font-medium text-sky-700">Open Paired Photo Studio</Link>.</p>
  </div>;
}
