"use client";

import { useState } from "react";
import { Check, Palette, User } from "lucide-react";
import { PageHeader } from "@/components/studio/page-header";
import { EngineBanner } from "@/components/studio/engine-banner";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useStore } from "@/lib/state/store";
import { BACKGROUND_PRESETS, parseColor } from "@/lib/config/backgrounds";
import type { BackgroundState } from "@/lib/state/types";
import { cn } from "@/lib/utils";

function backgroundCss(bg: BackgroundState): string {
  switch (bg.kind) {
    case "preset":
      return bg.preset.hex;
    case "custom":
      return bg.hex;
    case "gradient":
      return `linear-gradient(160deg, ${bg.from}, ${bg.to})`;
    default:
      return "#E8EBEF";
  }
}

export default function BackgroundPage() {
  const { state, dispatch } = useStore();
  const bg = state.edit.background;
  const [customInput, setCustomInput] = useState("");
  const [customError, setCustomError] = useState<string | null>(null);
  const [gradFrom, setGradFrom] = useState("#DCEEFF");
  const [gradTo, setGradTo] = useState("#2563EB");

  function setBackground(next: BackgroundState) {
    dispatch({ type: "edit-set", patch: { background: next } });
  }

  function applyCustom() {
    const hex = parseColor(customInput);
    if (!hex) {
      setCustomError("Enter a HEX value like #1E3A8A or RGB like rgb(30, 58, 138).");
      return;
    }
    setCustomError(null);
    setBackground({ kind: "custom", hex });
    setCustomInput("");
  }

  const isPresetActive = (id: string) => bg.kind === "preset" && bg.preset.id === id;

  return (
    <div>
      <PageHeader
        title="Background Studio"
        description="Choose a studio backdrop. Replacement applies to the subject once segmentation is connected."
      />

      <div className="space-y-6">
        <EngineBanner />

        <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_360px]">
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Premium backdrops</CardTitle>
                <CardDescription>Tap a colour to select it.</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-4 gap-3 sm:grid-cols-5 md:grid-cols-7">
                  {BACKGROUND_PRESETS.map((p) => {
                    const active = isPresetActive(p.id);
                    return (
                      <button
                        key={p.id}
                        onClick={() => setBackground({ kind: "preset", preset: p })}
                        aria-pressed={active}
                        aria-label={`${p.name} ${p.hex}`}
                        className="group flex flex-col items-center gap-1.5 text-center"
                      >
                        <span
                          className={cn(
                            "relative flex aspect-square w-full items-center justify-center rounded-xl ring-1 ring-inset ring-slate-900/10 transition group-hover:scale-[1.03]",
                            active && "ring-2 ring-sky-500 ring-offset-2"
                          )}
                          style={{ backgroundColor: p.hex }}
                        >
                          {active && <Check className={cn("size-5", ["#FFFFFF", "#F7F8FA", "#E8EBEF", "#C9CED6", "#DCEEFF", "#E6DDF5", "#FFF1DC", "#F5D5C7"].includes(p.hex) ? "text-slate-800" : "text-white")} />}
                        </span>
                        <span className="break-anywhere line-clamp-2 text-[11px] leading-tight text-slate-600">{p.name}</span>
                      </button>
                    );
                  })}
                </div>
              </CardContent>
            </Card>

            <div className="grid gap-6 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>Custom colour</CardTitle>
                  <CardDescription>HEX (#1E3A8A) or RGB (rgb(30, 58, 138)).</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex gap-2">
                    <input
                      value={customInput}
                      onChange={(e) => setCustomInput(e.target.value)}
                      onKeyDown={(e) => e.key === "Enter" && applyCustom()}
                      placeholder="#1E3A8A"
                      aria-label="Custom colour value"
                      aria-invalid={customError ? true : undefined}
                      className="h-10 min-w-0 flex-1 rounded-xl border border-slate-200 bg-white px-3 font-mono text-sm outline-none focus:border-sky-500 focus:ring-2 focus:ring-sky-500/20"
                    />
                    <Button onClick={applyCustom} variant="outline">Apply</Button>
                  </div>
                  {customError && <p role="alert" className="text-xs text-red-600">{customError}</p>}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Gradient</CardTitle>
                  <CardDescription>Two-colour vertical gradient.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center gap-3">
                    <label className="flex items-center gap-2 text-xs text-slate-600">
                      From
                      <input type="color" value={gradFrom} onChange={(e) => setGradFrom(e.target.value)} className="size-9 cursor-pointer rounded-lg border border-slate-200 bg-white p-1" aria-label="Gradient start colour" />
                    </label>
                    <label className="flex items-center gap-2 text-xs text-slate-600">
                      To
                      <input type="color" value={gradTo} onChange={(e) => setGradTo(e.target.value)} className="size-9 cursor-pointer rounded-lg border border-slate-200 bg-white p-1" aria-label="Gradient end colour" />
                    </label>
                    <Button variant="outline" size="sm" className="ml-auto" onClick={() => setBackground({ kind: "gradient", from: gradFrom, to: gradTo })}>
                      Apply
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardContent className="flex flex-col gap-3 p-5 sm:flex-row sm:items-center sm:justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-900">Keep the original background</p>
                  <p className="text-xs text-slate-500">Removes any background choice from this photo.</p>
                </div>
                <Button variant="outline" onClick={() => setBackground({ kind: "none" })} disabled={bg.kind === "none"}>
                  No change
                </Button>
              </CardContent>
            </Card>
          </div>

          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Preview</CardTitle>
                <CardDescription>Illustrative only. The subject is not segmented yet.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <div
                  className="relative flex aspect-[4/5] w-full items-end justify-center overflow-hidden rounded-2xl ring-1 ring-slate-900/10"
                  style={{ background: bg.kind === "none" ? "repeating-linear-gradient(45deg,#f1f5f9 0 10px,#e2e8f0 10px 20px)" : backgroundCss(bg) }}
                >
                  <div className="mb-6 flex size-40 items-center justify-center rounded-full bg-slate-300/60 text-slate-500">
                    <User className="size-20" />
                  </div>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-slate-600">Selected</span>
                  <Badge tone="info">
                    {bg.kind === "none" && "Original"}
                    {bg.kind === "preset" && `${bg.preset.name} · ${bg.preset.hex}`}
                    {bg.kind === "custom" && bg.hex}
                    {bg.kind === "gradient" && `${bg.from} → ${bg.to}`}
                  </Badge>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2"><Palette className="size-4" /> Requirements</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 text-sm text-slate-600">
                <p>Automatic background removal needs a segmentation model on the engine. It is not included with this app.</p>
                <p>Hair edges and halos are checked after replacement in Phase 4.</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
