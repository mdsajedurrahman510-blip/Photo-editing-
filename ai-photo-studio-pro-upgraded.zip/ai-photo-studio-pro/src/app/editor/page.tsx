"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { CheckCircle2, Download, ImagePlus, LoaderCircle, RefreshCw, ShieldCheck, Sparkles, Trash2, Users } from "lucide-react";
import { PageHeader } from "@/components/studio/page-header";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useStore } from "@/lib/state/store";
import { getFile, getFileUrl, getProcessedFile, registerFile, registerProcessedFile, releaseFile, getProcessedFileUrl } from "@/lib/state/file-registry";
import { readImageMeta } from "@/lib/image/read-meta";
import { validateImage } from "@/lib/upload-rules";
import { newId, formatBytes } from "@/lib/utils";
import { BACKGROUND_PRESETS } from "@/lib/config/backgrounds";
import { downloadBlob, enhanceImageInBrowser, type BrowserEnhancementOptions } from "@/lib/image/browser-engine";
import { EngineBadge } from "@/components/studio/engine-banner";
import type { ImageAsset } from "@/lib/state/types";

type PairMode = "single" | "paired";

export default function EditorPage() {
  const { state, dispatch } = useStore();
  const [notice, setNotice] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [mode, setMode] = useState<PairMode>("single");
  const [processed, setProcessed] = useState<Record<string, string>>({});
  const [metadata, setMetadata] = useState<Record<string, string>>({});
  const [settings, setSettings] = useState<BrowserEnhancementOptions>({ brightness: 0, contrast: 6, saturation: 0, denoise: 22, sharpness: 24, faceLight: 18, autoLight: true });
  const [bgColor, setBgColor] = useState("#00A8E8");
  useEffect(() => {
    const selected = state.edit.background;
    if (selected.kind === "preset") setBgColor(selected.preset.hex);
    else if (selected.kind === "custom") setBgColor(selected.hex);
    else if (selected.kind === "gradient") setBgColor(selected.from);
  }, [state.edit.background]);
  const [faceCount, setFaceCount] = useState<number | null>(null);
  const [detecting, setDetecting] = useState(false);

  const active = useMemo(() => state.assets.find((a) => a.id === state.activeAssetId) ?? state.assets[0] ?? null, [state.assets, state.activeAssetId]);
  const activeOriginal = active ? getFileUrl(active.id) : null;
  const activeOutput = active ? (processed[active.id] ?? getProcessedFileUrl(active.id)) : null;


  async function handleFiles(files: FileList | File[]) {
    setNotice(null);
    setBusy(true);
    const list = Array.from(files).slice(0, 30);
    const added: ImageAsset[] = [];
    for (const file of list) {
      const validation = validateImage(file);
      if (!validation.ok) { setNotice(validation.error ?? "Unsupported image."); continue; }
      try {
        const meta = await readImageMeta(file);
        const id = newId();
        registerFile(id, file);
        const asset: ImageAsset = { id, name: file.name, mime: file.type, sizeBytes: file.size, width: meta.width, height: meta.height, addedAt: new Date().toISOString() };
        dispatch({ type: "add-image", asset });
        added.push(asset);
      } catch (error) {
        setNotice(error instanceof Error ? error.message : `Could not read ${file.name}.`);
      }
    }
    if (added[0]) dispatch({ type: "set-active", id: added[0].id });
    setBusy(false);
  }

  function setOption<K extends keyof BrowserEnhancementOptions>(key: K, value: BrowserEnhancementOptions[K]) {
    setSettings((old) => ({ ...old, [key]: value }));
  }

  async function enhanceCurrent() {
    if (!active) return;
    const file = getFile(active.id);
    if (!file) { setNotice("This photo is no longer in memory. Please upload it again."); return; }
    setBusy(true); setNotice(null);
    try {
      let blob: Blob;
      let engineName = "Browser photo engine";
      // Prefer a connected Python engine; use real local classical processing as fallback.
      const form = new FormData();
      form.append("image", file, file.name);
      form.append("settings", JSON.stringify(settings));
      let response: Response | null = null;
      try { response = await fetch("/api/engine/process", { method: "POST", body: form }); } catch { response = null; }
      if (response?.ok) {
        blob = await response.blob();
        engineName = response.headers.get("X-Processing-Engine") ?? "Connected CPU engine";
      } else {
        const result = await enhanceImageInBrowser(file, settings);
        blob = result.blob;
        engineName = "On-device browser engine";
      }
      const nextUrl = registerProcessedFile(active.id, blob, `${active.name.replace(/\.[^.]+$/, "")}-studio.jpg`);
      setProcessed((old) => ({ ...old, [active.id]: nextUrl }));
      setMetadata((old) => ({ ...old, [active.id]: `${engineName} · non-generative processing` }));
      dispatch({ type: "set-active", id: active.id });
      setNotice(`Completed: ${active.name}. The original file was not overwritten.`);
    } catch (error) {
      setNotice(error instanceof Error ? error.message : "Photo processing failed.");
    } finally { setBusy(false); }
  }

  async function removeBackground() {
    if (!active) return;
    const file = getProcessedFile(active.id) ?? getFile(active.id);
    if (!file) { setNotice("Please upload the photo again."); return; }
    setBusy(true); setNotice(null);
    try {
      const form = new FormData(); form.append("image", file, file.name); form.append("color", bgColor);
      const res = await fetch("/api/engine/background", { method: "POST", body: form });
      if (!res.ok) {
        let message = "Background removal is not available on the connected engine.";
        try { const json = await res.json(); message = json.error ?? json.detail ?? message; } catch { /* use fallback */ }
        throw new Error(String(message).replace(/[\[\]{}"]+/g, "").slice(0, 260));
      }
      const blob = await res.blob(); const nextUrl = registerProcessedFile(active.id, blob, `${active.name.replace(/\.[^.]+$/, "")}-background.jpg`);
      setProcessed((old) => ({ ...old, [active.id]: nextUrl }));
      setMetadata((old) => ({ ...old, [active.id]: `Background segmented · ${bgColor}` }));
      setNotice("Background replacement completed.");
    } catch (error) { setNotice(error instanceof Error ? error.message : "Background replacement failed."); }
    finally { setBusy(false); }
  }

  async function detectFaces() {
    if (!active) return;
    const file = getFile(active.id); if (!file) return;
    setDetecting(true); setFaceCount(null); setNotice(null);
    try {
      const form = new FormData(); form.append("image", file, file.name);
      const res = await fetch("/api/engine/faces", { method: "POST", body: form });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error ?? "Connect the optional Python engine to localize faces.");
      setFaceCount(Number(json.count ?? 0));
      setNotice(`Face localization found ${json.count ?? 0} face(s). This detector is approximate; check the framing visually.`);
    } catch (error) { setNotice(error instanceof Error ? error.message : "Face localization unavailable."); }
    finally { setDetecting(false); }
  }

  function downloadCurrent() {
    if (!active) return;
    const url = processed[active.id] ?? getProcessedFileUrl(active.id);
    if (!url) return;
    fetch(url).then((r) => r.blob()).then((blob) => downloadBlob(blob, `${active.name.replace(/\.[^.]+$/, "")}-studio.jpg`)).catch(() => setNotice("Download could not be prepared."));
  }

  function removeAsset(id: string) {
    setProcessed((old) => { const copy = { ...old }; delete copy[id]; return copy; });
    releaseFile(id); dispatch({ type: "remove-image", id });
  }

  return (
    <div className="space-y-6">
      <PageHeader title="Professional Photo Editor" description="Non-generative, identity-conscious photo finishing with an optional connected AI engine." actions={<EngineBadge />} />
      {notice && <div role="status" className="rounded-xl border border-sky-200 bg-sky-50 px-4 py-3 text-sm text-sky-900">{notice}</div>}
      <div className="flex flex-wrap items-center gap-2">
        <button onClick={() => setMode("single")} className={`rounded-xl px-4 py-2 text-sm font-medium ${mode === "single" ? "bg-navy-900 text-white" : "border bg-white text-slate-700"}`}>Single Photo</button>
        <button onClick={() => { setMode("paired"); setFaceCount(null); }} className={`rounded-xl px-4 py-2 text-sm font-medium ${mode === "paired" ? "bg-navy-900 text-white" : "border bg-white text-slate-700"}`}><Users className="mr-2 inline size-4" />Two-Person Paired Photo</button>
        <span className="text-xs text-slate-500">Paired mode keeps the complete two-person frame together.</span>
      </div>

      {!active ? (
        <label className="flex min-h-64 cursor-pointer flex-col items-center justify-center rounded-3xl border-2 border-dashed border-slate-300 bg-white p-8 text-center transition hover:border-sky-400 hover:bg-sky-50/40">
          <ImagePlus className="size-10 text-sky-600" />
          <span className="mt-3 text-base font-semibold text-slate-900">Upload your photograph(s)</span>
          <span className="mt-1 text-sm text-slate-500">JPG, PNG or WebP · select up to 30 at a time · 50 MB per file</span>
          <input className="sr-only" type="file" accept="image/jpeg,image/png,image/webp" multiple onChange={(e) => { if (e.target.files) void handleFiles(e.target.files); e.currentTarget.value = ""; }} />
        </label>
      ) : (
        <div className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_350px]">
          <section className="min-w-0 space-y-4">
            <Card>
              <CardHeader className="flex-row items-center justify-between space-y-0">
                <div><CardTitle>{mode === "paired" ? "Two-person portrait" : "Photo preview"}</CardTitle><CardDescription>{active.width} × {active.height} px · {formatBytes(active.sizeBytes)}</CardDescription></div>
                {activeOutput && <Badge tone="success"><CheckCircle2 className="mr-1 size-3"/> Enhanced</Badge>}
              </CardHeader>
              <CardContent>
                <div className="grid gap-3 md:grid-cols-2">
                  <div className="overflow-hidden rounded-xl border bg-slate-100">
                    <div className="border-b bg-white px-3 py-2 text-xs font-medium text-slate-600">Original</div>
                    {activeOriginal && <img src={activeOriginal} alt="Original upload" className="max-h-[620px] w-full object-contain"/>}
                  </div>
                  <div className="overflow-hidden rounded-xl border bg-slate-100">
                    <div className="border-b bg-white px-3 py-2 text-xs font-medium text-slate-600">Processed result</div>
                    {activeOutput ? <img src={activeOutput} alt="Processed result" className="max-h-[620px] w-full object-contain"/> : <div className="flex min-h-64 items-center justify-center p-8 text-center text-sm text-slate-500">Run AI Auto Enhance to create a real processed copy. Your original remains unchanged.</div>}
                  </div>
                </div>
                {activeOutput && <p className="mt-3 text-xs text-slate-500">{metadata[active.id] ?? "Processed copy"}</p>}
              </CardContent>
            </Card>
            {mode === "paired" && <Card><CardContent className="flex flex-col gap-3 p-4 sm:flex-row sm:items-center sm:justify-between"><div><p className="text-sm font-semibold text-slate-900">Two-person check</p><p className="text-xs text-slate-500">Optional face localization requires the Python engine. It does not verify identity.</p>{faceCount !== null && <p className="mt-1 text-sm font-medium text-sky-800">Detected faces: {faceCount}</p>}</div><Button variant="outline" onClick={() => void detectFaces()} disabled={detecting}>{detecting ? <LoaderCircle className="animate-spin"/> : <Users/>} Detect faces</Button></CardContent></Card>}
            <Card><CardHeader className="flex-row items-center justify-between"><div><CardTitle>Your photos ({state.assets.length})</CardTitle><CardDescription>Select a photo to edit it.</CardDescription></div><label className="cursor-pointer"><span className="inline-flex h-9 items-center gap-2 rounded-xl border bg-white px-3 text-xs font-medium"><ImagePlus className="size-4"/> Add more</span><input className="sr-only" type="file" accept="image/jpeg,image/png,image/webp" multiple onChange={(e) => { if (e.target.files) void handleFiles(e.target.files); e.currentTarget.value = ""; }}/></label></CardHeader><CardContent><div className="grid grid-cols-3 gap-3 sm:grid-cols-5 lg:grid-cols-6">{state.assets.map((asset) => <div key={asset.id} className="relative min-w-0"><button onClick={() => dispatch({ type: "set-active", id: asset.id })} className={`w-full overflow-hidden rounded-xl border-2 text-left ${asset.id === active.id ? "border-sky-500" : "border-transparent"}`}><img src={getFileUrl(asset.id) ?? ""} alt={asset.name} className="aspect-square w-full object-cover"/><span className="block truncate px-1.5 py-1 text-[11px] text-slate-600">{asset.name}</span></button><button onClick={() => removeAsset(asset.id)} aria-label={`Remove ${asset.name}`} className="absolute right-1 top-1 rounded-full bg-white/90 p-1 text-slate-600 shadow"><Trash2 className="size-3.5"/></button></div>)}</div></CardContent></Card>
          </section>

          <aside className="space-y-4 xl:sticky xl:top-6 xl:h-fit">
            <Card><CardHeader><CardTitle>Automatic enhancement</CardTitle><CardDescription>Gentle, non-generative photo finishing. No face reconstruction.</CardDescription></CardHeader><CardContent className="space-y-4">
              <Slider label="Brightness" value={settings.brightness ?? 0} min={-40} max={40} onChange={(v) => setOption("brightness", v)}/>
              <Slider label="Contrast" value={settings.contrast ?? 6} min={-20} max={30} onChange={(v) => setOption("contrast", v)}/>
              <Slider label="Noise reduction" value={settings.denoise ?? 22} min={0} max={60} onChange={(v) => setOption("denoise", v)}/>
              <Slider label="Natural sharpness" value={settings.sharpness ?? 24} min={0} max={60} onChange={(v) => setOption("sharpness", v)}/>
              <Slider label="Shadow lift" value={settings.faceLight ?? 18} min={0} max={50} onChange={(v) => setOption("faceLight", v)}/>
              <label className="flex items-center gap-2 text-xs text-slate-700"><input type="checkbox" checked={settings.autoLight !== false} onChange={(e) => setOption("autoLight", e.target.checked)}/> Adaptive auto exposure</label>
              <Button className="w-full" size="lg" disabled={busy} onClick={() => void enhanceCurrent()}>{busy ? <LoaderCircle className="animate-spin"/> : <Sparkles/>}{busy ? "Processing…" : "AI Auto Enhance"}</Button>
              {activeOutput && <Button className="w-full" variant="outline" onClick={downloadCurrent}><Download/> Download enhanced photo</Button>}
              <p className="text-[11px] leading-relaxed text-slate-500">This browser engine adjusts captured pixels and does not reconstruct missing detail. For stronger learned restoration, connect the optional server engine. Facial identity can never be guaranteed by software alone.</p>
            </CardContent></Card>
            <Card><CardHeader><CardTitle>Studio background</CardTitle><CardDescription>Choose a color. Actual background removal requires the optional segmentation model on the Python engine.</CardDescription></CardHeader><CardContent className="space-y-3"><div className="flex items-center gap-3"><input type="color" value={bgColor} onChange={(e) => setBgColor(e.target.value)} className="size-11 cursor-pointer rounded-lg border bg-white p-1"/><input value={bgColor.toUpperCase()} onChange={(e) => setBgColor(e.target.value)} className="h-10 min-w-0 flex-1 rounded-lg border px-3 font-mono text-sm"/></div><div className="grid grid-cols-7 gap-2">{BACKGROUND_PRESETS.map((preset) => <button key={preset.id} title={preset.name} onClick={() => setBgColor(preset.hex)} className={`aspect-square rounded-lg border ${bgColor.toUpperCase() === preset.hex ? "ring-2 ring-sky-500 ring-offset-2" : ""}`} style={{ backgroundColor: preset.hex }}/>)}</div><Button variant="outline" className="w-full" disabled={busy} onClick={() => void removeBackground()}>Apply selected background</Button><Link href="/background" className="block text-center text-xs font-medium text-sky-700">Open Background Studio</Link></CardContent></Card>
            <div className="rounded-xl border border-emerald-200 bg-emerald-50 p-3 text-xs text-emerald-900"><ShieldCheck className="mb-1 size-4"/><strong>Identity-first policy</strong><p className="mt-1">No face replacement, reshaping, or generative face reconstruction is performed by the built-in browser pipeline.</p></div>
            <Button variant="ghost" className="w-full" onClick={() => { setSettings({ brightness: 0, contrast: 6, saturation: 0, denoise: 22, sharpness: 24, faceLight: 18, autoLight: true }); setNotice("Enhancement settings reset."); }}><RefreshCw/> Reset adjustments</Button>
          </aside>
        </div>
      )}
    </div>
  );
}

function Slider({ label, value, min, max, onChange }: { label: string; value: number; min: number; max: number; onChange: (value: number) => void }) {
  return <label className="block space-y-1.5"><span className="flex justify-between text-xs font-medium text-slate-700"><span>{label}</span><span className="font-mono text-slate-500">{value}</span></span><input type="range" min={min} max={max} value={value} onChange={(e) => onChange(Number(e.target.value))} className="w-full accent-sky-600"/></label>;
}
