"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import { Archive, Download, FileImage, Images, IdCard, Users } from "lucide-react";
import { PageHeader } from "@/components/studio/page-header";
import { EngineBadge } from "@/components/studio/engine-banner";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useStore } from "@/lib/state/store";
import { getFile, getProcessedFile, getProcessedFileUrl } from "@/lib/state/file-registry";
import { createZip } from "@/lib/image/zip";
import { downloadBlob } from "@/lib/image/browser-engine";

export default function ExportPage() {
  const { state, dispatch } = useStore();
  const [notice, setNotice] = useState<string | null>(null);
  const active = useMemo(
    () => state.assets.find((asset) => asset.id === state.activeAssetId) ?? state.assets[0] ?? null,
    [state.assets, state.activeAssetId],
  );
  const processedAssets = state.assets.filter((asset) => Boolean(getProcessedFile(asset.id)));

  function downloadActiveProcessed() {
    if (!active) return;
    const blob = getProcessedFile(active.id);
    if (!blob) { setNotice("This photo has not been enhanced in this browser session yet. Open Photo Editor and run AI Auto Enhance first."); return; }
    downloadBlob(blob, `${active.name.replace(/\.[^.]+$/, "")}-studio.jpg`);
    setNotice(`Downloading the enhanced version of ${active.name}.`);
  }

  async function downloadProcessedZip() {
    const entries = state.assets.flatMap((asset) => {
      const blob = getProcessedFile(asset.id);
      return blob ? [{ name: `${asset.name.replace(/\.[^.]+$/, "")}-studio.jpg`, blob }] : [];
    });
    if (!entries.length) { setNotice("No enhanced images are available yet. Process photos in the editor or Batch Processing first."); return; }
    try {
      const zip = await createZip(entries);
      downloadBlob(zip, "ai-photo-studio-processed-photos.zip");
      setNotice(`${entries.length} processed photo(s) added to the ZIP archive.`);
    } catch (error) {
      setNotice(error instanceof Error ? error.message : "Could not create the ZIP archive.");
    }
  }

  return (
    <div className="space-y-6">
      <PageHeader title="Export Center" description="Download real processed photos, or open the dedicated passport and paired print exporters." actions={<EngineBadge />} />
      {notice && <div role="status" className="rounded-xl border border-sky-200 bg-sky-50 px-4 py-3 text-sm text-sky-900">{notice}</div>}

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2"><FileImage className="size-5"/> Selected photo</CardTitle>
            <CardDescription>{active ? active.name : "No photo has been added to the workspace."}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {active ? (
              <>
                <div className="overflow-hidden rounded-xl border bg-slate-50">
                  {getProcessedFileUrl(active.id) ? (
                    <img src={getProcessedFileUrl(active.id)!} alt="Enhanced photo preview" className="mx-auto max-h-72 w-full object-contain" />
                  ) : <div className="p-8 text-center text-sm text-slate-500">Not enhanced yet</div>}
                </div>
                <div className="flex flex-wrap gap-2">
                  <Badge tone="neutral">{active.width} × {active.height} px</Badge>
                  <Badge tone={getProcessedFile(active.id) ? "success" : "neutral"}>{getProcessedFile(active.id) ? "Enhanced output ready" : "Original only"}</Badge>
                </div>
                <Button className="w-full" onClick={downloadActiveProcessed} disabled={!getProcessedFile(active.id)}><Download/> Download enhanced JPG</Button>
                <Link href="/editor" className="block text-center text-sm font-medium text-sky-700 hover:underline">Open Photo Editor</Link>
              </>
            ) : (
              <Link href="/editor" className="inline-flex items-center gap-2 text-sm font-medium text-sky-700"><Images className="size-4"/> Upload a photo in the editor</Link>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2"><Archive className="size-5"/> Batch export</CardTitle>
            <CardDescription>{processedAssets.length} enhanced photo(s) are currently available in this browser session.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="rounded-xl bg-slate-50 p-4 text-sm text-slate-600">
              The ZIP contains only photos that have a completed processed output. Original photographs are not silently labelled as enhanced.
            </div>
            <Button className="w-full" onClick={() => void downloadProcessedZip()} disabled={processedAssets.length === 0}><Archive/> Download processed photos (ZIP)</Button>
            <Link href="/batch" className="block text-center text-sm font-medium text-sky-700 hover:underline">Open Batch Processing</Link>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader><CardTitle className="flex items-center gap-2"><IdCard className="size-5"/> Individual passport prints</CardTitle><CardDescription>Exact millimetre-based photo size, print sheet, JPG or PDF.</CardDescription></CardHeader>
          <CardContent><Button asChild variant="outline" className="w-full"><Link href="/passport">Open Passport Studio</Link></Button></CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle className="flex items-center gap-2"><Users className="size-5"/> Two-person paired print</CardTitle><CardDescription>Keep both people together inside one accurately sized canvas.</CardDescription></CardHeader>
          <CardContent><Button asChild variant="outline" className="w-full"><Link href="/paired">Open Paired Photo Studio</Link></Button></CardContent>
        </Card>
      </div>
      <p className="text-xs leading-relaxed text-slate-500">Browser-session files are held temporarily in memory. Reloading or closing the tab can clear the workspace; download important results before leaving.</p>
    </div>
  );
}
