"use client";

import Link from "next/link";
import { ArrowRight, Image as ImageIcon, IdCard, ListOrdered, Sparkles, Users } from "lucide-react";
import { PageHeader } from "@/components/studio/page-header";
import { EngineBanner } from "@/components/studio/engine-banner";
import { Thumb } from "@/components/studio/thumb";
import { FadeIn } from "@/components/studio/fade-in";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useStore } from "@/lib/state/store";
import { PIPELINE_STAGES } from "@/lib/engine/types";
import { formatBytes } from "@/lib/utils";

const QUICK_ACTIONS = [
  { href: "/editor", title: "Open Photo Editor", desc: "Upload a photo and compare", icon: ImageIcon },
  { href: "/enhance", title: "AI Enhancement", desc: "Review the restoration pipeline", icon: Sparkles },
  { href: "/passport", title: "Passport Photo", desc: "Plan a print sheet", icon: IdCard },
  { href: "/batch", title: "Batch Processing", desc: "Queue many photos", icon: ListOrdered },
  { href: "/paired", title: "Paired Photo Studio", desc: "Create accurate two-person prints", icon: Users },
];

export default function DashboardPage() {
  const { state } = useStore();
  const recent = state.assets.slice(0, 6);
  const modelStages = PIPELINE_STAGES.filter((s) => s.model);

  return (
    <FadeIn>
      <PageHeader
        title="Dashboard"
        description="Restore, frame and print photos while keeping every face true to the original."
        actions={
          <Button asChild>
            <Link href="/editor">Upload a photo</Link>
          </Button>
        }
      />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="Photos" value={state.assets.length} />
        <StatCard label="Photo tools" value={10} />
        <StatCard label="Default DPI" value={300} />
        <StatCard label="Undo steps" value={state.history.past.length} />
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-2">
          <EngineBanner />

          <Card>
            <CardHeader>
              <CardTitle>Start a job</CardTitle>
              <CardDescription>Jump into any workflow.</CardDescription>
            </CardHeader>
            <CardContent className="grid gap-3 sm:grid-cols-2">
              {QUICK_ACTIONS.map((a) => {
                const Icon = a.icon;
                return (
                  <Link
                    key={a.href}
                    href={a.href}
                    className="group flex items-center gap-3 rounded-xl border border-slate-200 p-4 transition-colors hover:border-slate-300 hover:bg-slate-50"
                  >
                    <div className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-navy-50 text-navy-900">
                      <Icon className="size-5" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-medium text-slate-900">{a.title}</p>
                      <p className="text-xs text-slate-500">{a.desc}</p>
                    </div>
                    <ArrowRight className="size-4 text-slate-400 transition-transform group-hover:translate-x-0.5" />
                  </Link>
                );
              })}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex-row items-center justify-between space-y-0">
              <div>
                <CardTitle>Recent photos</CardTitle>
                <CardDescription>Photos added in this workspace.</CardDescription>
              </div>
              <Link href="/editor" className="text-sm font-medium text-sky-700 hover:underline">
                View all
              </Link>
            </CardHeader>
            <CardContent>
              {recent.length === 0 ? (
                <EmptyState text="No photos yet. Open the Photo Editor to upload your first image." />
              ) : (
                <div className="grid grid-cols-3 gap-3 sm:grid-cols-6">
                  {recent.map((a) => (
                    <Link key={a.id} href="/editor" className="group space-y-1.5">
                      <Thumb id={a.id} alt={a.name} className="aspect-square w-full rounded-xl ring-1 ring-slate-200 group-hover:ring-sky-400" />
                      <p className="break-anywhere truncate text-xs text-slate-600">{a.name}</p>
                    </Link>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        <Card className="h-fit">
          <CardHeader>
            <CardTitle>Pipeline overview</CardTitle>
            <CardDescription>
              {PIPELINE_STAGES.length} stages · {modelStages.length} need external models
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2.5">
              {PIPELINE_STAGES.map((s) => (
                <li key={s.id} className="flex items-start justify-between gap-2 text-sm">
                  <span className="text-slate-700">{s.label}</span>
                  <div className="flex shrink-0 gap-1">
                    {s.touchesFace && <Badge tone="info">Face</Badge>}
                    {s.model && <Badge tone="neutral">Model</Badge>}
                  </div>
                </li>
              ))}
            </ul>
            <p className="mt-4 text-xs text-slate-500">
              Stages marked Model need external weights installed on the engine. None are bundled with this app.
            </p>
          </CardContent>
        </Card>
      </div>

      {state.assets.length > 0 && (
        <p className="mt-6 text-xs text-slate-400">
          Latest upload: {state.assets[0].name} ({formatBytes(state.assets[0].sizeBytes)})
        </p>
      )}
    </FadeIn>
  );
}

function StatCard({ label, value }: { label: string; value: number }) {
  return (
    <Card className="p-5">
      <p className="text-xs font-medium uppercase tracking-wide text-slate-500">{label}</p>
      <p className="mt-2 text-3xl font-semibold tabular-nums text-slate-900">{value}</p>
    </Card>
  );
}

function EmptyState({ text }: { text: string }) {
  return <p className="rounded-xl bg-slate-50 p-6 text-center text-sm text-slate-500">{text}</p>;
}
