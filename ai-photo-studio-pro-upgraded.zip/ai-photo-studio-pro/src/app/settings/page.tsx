"use client";

import { useState } from "react";
import { ShieldCheck, Trash2 } from "lucide-react";
import { PageHeader } from "@/components/studio/page-header";
import { EngineBanner } from "@/components/studio/engine-banner";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useStore, STORAGE_KEY } from "@/lib/state/store";
import { releaseAllFiles } from "@/lib/state/file-registry";
import { DPI_OPTIONS } from "@/lib/config/passport";
import { IDENTITY_RULES } from "@/lib/engine/identity-policy";
import { cn } from "@/lib/utils";

const RETENTION_OPTIONS = [
  { hours: 1, label: "1 hour" },
  { hours: 24, label: "24 hours" },
  { hours: 168, label: "7 days" },
  { hours: 720, label: "30 days" },
];

export default function SettingsPage() {
  const { state, dispatch } = useStore();
  const [confirming, setConfirming] = useState(false);
  const { settings } = state;

  function clearAll() {
    releaseAllFiles();
    try {
      localStorage.removeItem(STORAGE_KEY);
    } catch {
      /* storage unavailable; in-memory state is still cleared below */
    }
    dispatch({ type: "clear-all" });
    setConfirming(false);
  }

  return (
    <div>
      <PageHeader title="Settings" description="Preferences for this self-hosted workspace." />

      <div className="space-y-6">
        <EngineBanner />

        <div className="grid gap-6 lg:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle>Defaults</CardTitle>
              <CardDescription>Applied to new exports and sheets.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <span className="text-sm font-medium text-slate-800">Default print DPI</span>
                <div className="flex flex-wrap gap-2">
                  {DPI_OPTIONS.map((d) => (
                    <Button
                      key={d}
                      size="sm"
                      variant={settings.defaultDpi === d ? "default" : "outline"}
                      aria-pressed={settings.defaultDpi === d}
                      onClick={() => dispatch({ type: "set-settings", patch: { defaultDpi: d } })}
                    >
                      {d}
                    </Button>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <label htmlFor="retention" className="text-sm font-medium text-slate-800">Temporary file retention</label>
                <select
                  id="retention"
                  value={settings.tempRetentionHours}
                  onChange={(e) => dispatch({ type: "set-settings", patch: { tempRetentionHours: Number(e.target.value) } })}
                  className="h-10 w-full rounded-xl border border-slate-200 bg-white px-3 text-sm"
                >
                  {RETENTION_OPTIONS.map((o) => (
                    <option key={o.hours} value={o.hours}>{o.label}</option>
                  ))}
                </select>
                <p className="text-xs text-slate-500">
                  How long processing temp files are kept on the engine host. Enforced by the engine from Phase 2.
                </p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <ShieldCheck className="size-4 text-emerald-600" /> Identity protection
              </CardTitle>
              <CardDescription>These rules apply to every processing stage and cannot be disabled.</CardDescription>
            </CardHeader>
            <CardContent>
              <ol className="space-y-2.5">
                {IDENTITY_RULES.map((rule, i) => (
                  <li key={rule} className="flex gap-3 text-sm text-slate-700">
                    <span className="font-mono text-xs text-slate-400">{String(i + 1).padStart(2, "0")}</span>
                    {rule}
                  </li>
                ))}
              </ol>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Deployment</CardTitle>
              <CardDescription>Single-user, photo-only workspace with browser-side processing and optional Python engine.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3 text-sm">
              <Row label="Mode" value={<Badge tone="neutral">Single user</Badge>} />
              <Row label="Storage" value="Browser session (metadata persisted)" />
              <Row label="Engine URL" value={<code className="font-mono text-xs">PHOTO_ENGINE_URL</code>} />
              <Row label="Accounts" value="Not enabled" />
            </CardContent>
          </Card>

          <Card className="border-red-200/70">
            <CardHeader>
              <CardTitle>Delete local data</CardTitle>
              <CardDescription>
                Removes all photos, queued jobs and settings from this browser. Your original files on disk are not touched.
              </CardDescription>
            </CardHeader>
            <CardContent className="flex flex-col gap-3 sm:flex-row sm:items-center">
              {!confirming ? (
                <Button variant="outline" className="border-red-200 text-red-700 hover:bg-red-50" onClick={() => setConfirming(true)}>
                  <Trash2 /> Delete all local data
                </Button>
              ) : (
                <>
                  <Button variant="danger" onClick={clearAll}>Yes, delete everything</Button>
                  <Button variant="ghost" onClick={() => setConfirming(false)}>Cancel</Button>
                </>
              )}
              <span className={cn("text-xs text-slate-500", confirming && "text-red-700")}>
                This cannot be undone.
              </span>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

function Row({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-3 border-b border-slate-100 pb-3 last:border-0 last:pb-0">
      <span className="text-slate-500">{label}</span>
      <span className="text-right text-slate-900">{value}</span>
    </div>
  );
}
