import Link from "next/link";
import { Shirt, ShieldCheck, Sparkles } from "lucide-react";
import { PageHeader } from "@/components/studio/page-header";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export default function ClothingPage() {
  return <div className="space-y-6">
    <PageHeader title="Clothing Enhancement Studio" description="Improve garment appearance while protecting the person's identity and the original outfit." actions={<Badge tone="warning">Segmentation model needed</Badge>}/>
    <div className="grid gap-5 lg:grid-cols-2">
      <Card><CardHeader><CardTitle className="flex items-center gap-2"><Shirt className="size-5"/> What works now</CardTitle><CardDescription>General photo finishing also affects the visible fabric in a natural way.</CardDescription></CardHeader><CardContent className="space-y-3 text-sm text-slate-600"><p>Use the Photo Editor's exposure, contrast, saturation, denoise, and sharpness settings to improve the photograph without replacing the outfit.</p><p>The built-in engine does not yet have a dedicated clothing segmentation model, so it will not pretend to isolate and retouch only the shirt or Panjabi.</p><Button asChild className="w-full"><Link href="/editor"><Sparkles/> Open Photo Editor</Link></Button></CardContent></Card>
      <Card><CardHeader><CardTitle className="flex items-center gap-2"><ShieldCheck className="size-5 text-emerald-600"/> Identity and garment protection</CardTitle></CardHeader><CardContent className="space-y-3 text-sm text-slate-600"><p>Original garment shape, patterns, buttons, collar and color should be preserved unless you explicitly choose a future clothing-replacement model.</p><p>AI clothing replacement is intentionally not enabled until a suitable licensed model is installed and tested. No generated outfit preview is fabricated.</p><Badge tone="success">No automatic outfit replacement</Badge></CardContent></Card>
    </div>
  </div>;
}
