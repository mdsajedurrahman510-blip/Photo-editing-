import Link from "next/link";
import { ShieldCheck, Sparkles, WandSparkles } from "lucide-react";
import { PageHeader } from "@/components/studio/page-header";
import { EngineBanner } from "@/components/studio/engine-banner";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

const steps = [
  ["Adaptive exposure", "Measures average image luminance and gently adjusts exposure."],
  ["Tone and contrast", "Applies controlled contrast and shadow lift without face reconstruction."],
  ["Noise softening", "Uses a restrained blur blend in the browser as a lightweight fallback."],
  ["Conservative sharpening", "Uses an unsharp mask to strengthen captured edges without generating details."],
  ["Optional Python processing", "Connects OpenCV denoising and approximate face localization when PHOTO_ENGINE_URL is configured."],
];
export default function EnhancePage() {
  return <div className="space-y-6">
    <PageHeader title="Photo Enhancement" description="A real, non-generative browser pipeline with an optional Python CPU engine." actions={<Badge tone="success">Identity-first</Badge>}/>
    <EngineBanner />
    <div className="grid gap-5 lg:grid-cols-[minmax(0,1fr)_340px]">
      <Card><CardHeader><CardTitle>Available processing stages</CardTitle><CardDescription>These operations act on the captured pixels. They do not invent facial details or reshape faces.</CardDescription></CardHeader><CardContent><ol className="space-y-3">{steps.map(([title, detail], i) => <li key={title} className="flex gap-3"><span className="flex size-7 shrink-0 items-center justify-center rounded-full bg-sky-50 text-xs font-semibold text-sky-800">{i + 1}</span><div><p className="text-sm font-semibold text-slate-900">{title}</p><p className="mt-0.5 text-xs leading-relaxed text-slate-500">{detail}</p></div></li>)}</ol></CardContent></Card>
      <Card><CardHeader><CardTitle className="flex items-center gap-2"><ShieldCheck className="size-4 text-emerald-600"/> Identity safeguard</CardTitle><CardDescription>Default processing is non-generative.</CardDescription></CardHeader><CardContent className="space-y-3 text-sm text-slate-600"><p>No face swap, face reconstruction, reshaping, age transformation, or AI beauty filter is used by the built-in engine.</p><p>Severely blurred details cannot be recovered with certainty. Software can improve visible information, but cannot guarantee the original face is perfectly preserved in every image.</p><Button asChild className="w-full"><Link href="/editor"><WandSparkles/> Open Photo Editor</Link></Button></CardContent></Card>
    </div>
    <p className="text-xs text-slate-500">Remini-level generative restoration is not bundled. Higher-end learned models require compatible weights, licenses, memory, and often GPU compute; this application reports those dependencies rather than pretending they are present.</p>
  </div>;
}
