import type { AppSettings, AppState, EditSettings, ImageAsset, PassportSettings } from "./types";

const HISTORY_LIMIT = 100;

export const DEFAULT_EDIT: EditSettings = {
  intensity: 50,
  denoise: 40,
  sharpness: 30,
  exposure: 0,
  cropRatio: "original",
  background: { kind: "none" },
  colorGrade: "natural-studio",
  outfitId: null,
  outfitPrompt: "",
  clothingEnabled: false,
};

export const DEFAULT_PASSPORT: PassportSettings = {
  photoSizeId: "40x50",
  customWidthMm: 35,
  customHeightMm: 45,
  sheetId: "4x6in",
  copies: 6,
  marginMm: 3,
  gapMm: 2,
  dpi: 300,
};

export const DEFAULT_SETTINGS: AppSettings = {
  defaultDpi: 300,
  tempRetentionHours: 24,
  defaultExportFormat: "jpg",
};

export const initialState: AppState = {
  hydrated: false,
  assets: [],
  activeAssetId: null,
  edit: DEFAULT_EDIT,
  passport: DEFAULT_PASSPORT,
  settings: DEFAULT_SETTINGS,
  history: { past: [], future: [] },
};

type Patch<T> = Partial<T>;

export type Action =
  | { type: "hydrate"; payload: Partial<AppState> }
  | { type: "add-image"; asset: ImageAsset }
  | { type: "remove-image"; id: string }
  | { type: "set-active"; id: string | null }
  | { type: "edit-live"; patch: Patch<EditSettings> }
  | { type: "edit-end" }
  | { type: "edit-set"; patch: Patch<EditSettings> }
  | { type: "undo" }
  | { type: "redo" }
  | { type: "reset-edit" }
  | { type: "set-passport"; patch: Patch<PassportSettings> }
  | { type: "set-settings"; patch: Patch<AppSettings> }
  | { type: "clear-all" };

const same = (a: unknown, b: unknown) => JSON.stringify(a) === JSON.stringify(b);
const pushHistory = (past: EditSettings[], snapshot: EditSettings) => [...past, snapshot].slice(-HISTORY_LIMIT);

/** Pure state reducer. Browser file bytes are managed separately by file-registry. */
export function reducer(state: AppState, action: Action): AppState {
  switch (action.type) {
    case "hydrate":
      return { ...state, ...action.payload, hydrated: true };
    case "add-image": {
      const assets = [action.asset, ...state.assets];
      return { ...state, assets, activeAssetId: state.activeAssetId ?? action.asset.id };
    }
    case "remove-image": {
      const assets = state.assets.filter((asset) => asset.id !== action.id);
      const activeAssetId = state.activeAssetId === action.id ? (assets[0]?.id ?? null) : state.activeAssetId;
      return { ...state, assets, activeAssetId };
    }
    case "set-active":
      return { ...state, activeAssetId: action.id };
    case "edit-live": {
      const base = state.history.base ?? state.edit;
      return { ...state, edit: { ...state.edit, ...action.patch }, history: { ...state.history, base } };
    }
    case "edit-end": {
      const base = state.history.base;
      if (!base) return state;
      const changed = !same(base, state.edit);
      return { ...state, history: { past: changed ? pushHistory(state.history.past, base) : state.history.past, future: changed ? [] : state.history.future } };
    }
    case "edit-set": {
      const next = { ...state.edit, ...action.patch };
      if (same(next, state.edit)) return state;
      return { ...state, edit: next, history: { past: pushHistory(state.history.past, state.edit), future: [] } };
    }
    case "undo": {
      const { past, future } = state.history;
      if (!past.length) return state;
      const previous = past[past.length - 1];
      return { ...state, edit: previous, history: { past: past.slice(0, -1), future: [state.edit, ...future] } };
    }
    case "redo": {
      const { past, future } = state.history;
      if (!future.length) return state;
      const [next, ...rest] = future;
      return { ...state, edit: next, history: { past: pushHistory(past, state.edit), future: rest } };
    }
    case "reset-edit":
      return { ...state, edit: DEFAULT_EDIT, history: { past: pushHistory(state.history.past, state.edit), future: [] } };
    case "set-passport":
      return { ...state, passport: { ...state.passport, ...action.patch } };
    case "set-settings":
      return { ...state, settings: { ...state.settings, ...action.patch } };
    case "clear-all":
      return { ...initialState, hydrated: true };
    default:
      return state;
  }
}
