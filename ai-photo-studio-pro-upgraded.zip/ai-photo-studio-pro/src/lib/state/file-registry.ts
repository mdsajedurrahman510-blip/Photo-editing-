/** Uploaded and processed image bytes live only in the current browser session. */
interface Entry { file: File; url: string }
interface ProcessedEntry { blob: Blob; url: string; name: string }
const registry = new Map<string, Entry>();
const processedRegistry = new Map<string, ProcessedEntry>();

export function registerFile(id: string, file: File): string {
  releaseFile(id);
  const url = URL.createObjectURL(file);
  registry.set(id, { file, url });
  return url;
}
export function getFileUrl(id: string): string | null { return registry.get(id)?.url ?? null; }
export function getFile(id: string): File | null { return registry.get(id)?.file ?? null; }
export function registerProcessedFile(id: string, blob: Blob, name = "processed-photo.jpg"): string {
  releaseProcessedFile(id);
  const url = URL.createObjectURL(blob);
  processedRegistry.set(id, { blob, url, name });
  return url;
}
export function getProcessedFileUrl(id: string): string | null { return processedRegistry.get(id)?.url ?? null; }
export function getProcessedFile(id: string): Blob | null { return processedRegistry.get(id)?.blob ?? null; }
export function getProcessedFileName(id: string): string | null { return processedRegistry.get(id)?.name ?? null; }
export function releaseProcessedFile(id: string): void {
  const entry = processedRegistry.get(id);
  if (entry) { URL.revokeObjectURL(entry.url); processedRegistry.delete(id); }
}
export function releaseFile(id: string): void {
  const entry = registry.get(id);
  if (entry) { URL.revokeObjectURL(entry.url); registry.delete(id); }
  releaseProcessedFile(id);
}
export function releaseAllFiles(): void {
  for (const id of registry.keys()) releaseFile(id);
  for (const id of processedRegistry.keys()) releaseProcessedFile(id);
}
