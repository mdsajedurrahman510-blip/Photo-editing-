"use client";

import {
  createContext,
  useContext,
  useEffect,
  useReducer,
  type Dispatch,
  type ReactNode,
} from "react";
import type { AppState, EditSettings } from "./types";
import { DEFAULT_EDIT, DEFAULT_PASSPORT, DEFAULT_SETTINGS, initialState, reducer } from "./reducer";
import type { Action } from "./reducer";

export { DEFAULT_EDIT, DEFAULT_PASSPORT, DEFAULT_SETTINGS, initialState, reducer } from "./reducer";
export type { Action } from "./reducer";
export const STORAGE_KEY = "aips.v1";

/** Persisted subset. Files and object URLs are never stored. */
function toPersisted(state: AppState) {
  return {
    assets: state.assets,
    activeAssetId: state.activeAssetId,
    edit: state.edit,
    passport: state.passport,
    settings: state.settings,
    history: { past: state.history.past.slice(-20), future: [] as EditSettings[] },
  };
}

function loadPersisted(): Partial<AppState> {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return {};
    const saved = JSON.parse(raw);
    return {
      assets: Array.isArray(saved.assets) ? saved.assets : [],
      activeAssetId: typeof saved.activeAssetId === "string" ? saved.activeAssetId : null,
      edit: { ...DEFAULT_EDIT, ...(saved.edit ?? {}) },
      passport: { ...DEFAULT_PASSPORT, ...(saved.passport ?? {}) },
      settings: { ...DEFAULT_SETTINGS, ...(saved.settings ?? {}) },
      history: {
        past: Array.isArray(saved.history?.past) ? saved.history.past : [],
        future: [],
      },
    };
  } catch {
    // Corrupt storage should never break the app; fall back to defaults.
    return {};
  }
}

interface StoreValue {
  state: AppState;
  dispatch: Dispatch<Action>;
}

const StoreContext = createContext<StoreValue | null>(null);

export function StoreProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(reducer, initialState);

  useEffect(() => {
    dispatch({ type: "hydrate", payload: loadPersisted() });
  }, []);

  useEffect(() => {
    if (!state.hydrated) return;
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(toPersisted(state)));
    } catch {
      // Quota or private-mode errors are non-fatal; state stays in memory.
    }
  }, [state]);

  return (
    <StoreContext.Provider value={{ state, dispatch }}>{children}</StoreContext.Provider>
  );
}

export function useStore(): StoreValue {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error("useStore must be used inside <StoreProvider>");
  return ctx;
}
