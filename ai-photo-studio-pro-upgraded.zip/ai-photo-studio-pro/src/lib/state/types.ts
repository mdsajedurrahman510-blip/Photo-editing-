import type { BackgroundPreset } from "../config/backgrounds";

export interface ImageAsset {
  id: string;
  name: string;
  mime: string;
  sizeBytes: number;
  width: number;
  height: number;
  addedAt: string;
}

export type BackgroundState =
  | { kind: "none" }
  | { kind: "preset"; preset: BackgroundPreset }
  | { kind: "custom"; hex: string }
  | { kind: "gradient"; from: string; to: string };

export interface EditSettings {
  intensity: number; // 0–100, enhancement strength
  denoise: number; // 0–100
  sharpness: number; // 0–100
  exposure: number; // -100…100
  cropRatio: "original" | "1:1" | "4:5" | "3:4";
  background: BackgroundState;
  colorGrade: string;
  outfitId: string | null;
  outfitPrompt: string;
  clothingEnabled: boolean;
}

export interface PassportSettings {
  photoSizeId: string;
  customWidthMm: number;
  customHeightMm: number;
  sheetId: string;
  copies: number;
  marginMm: number;
  gapMm: number;
  dpi: number;
}

export interface AppSettings {
  defaultDpi: number;
  tempRetentionHours: number;
  defaultExportFormat: "jpg" | "png" | "pdf";
}

export interface AppState {
  hydrated: boolean;
  assets: ImageAsset[];
  activeAssetId: string | null;
  edit: EditSettings;
  passport: PassportSettings;
  settings: AppSettings;
  history: { past: EditSettings[]; future: EditSettings[]; base?: EditSettings | null };
}
