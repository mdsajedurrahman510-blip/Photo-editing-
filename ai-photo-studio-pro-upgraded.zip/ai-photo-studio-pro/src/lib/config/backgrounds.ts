export interface BackgroundPreset {
  id: string;
  name: string;
  hex: string;
}

export const BACKGROUND_PRESETS: BackgroundPreset[] = [
  { id: "pure-white", name: "Pure White", hex: "#FFFFFF" },
  { id: "soft-white", name: "Soft White", hex: "#F7F8FA" },
  { id: "light-grey", name: "Light Grey", hex: "#E8EBEF" },
  { id: "professional-grey", name: "Professional Grey", hex: "#C9CED6" },
  { id: "sky-blue", name: "Sky Blue", hex: "#00A8E8" },
  { id: "royal-blue", name: "Royal Blue", hex: "#2563EB" },
  { id: "deep-navy", name: "Deep Navy", hex: "#142B4A" },
  { id: "soft-blue", name: "Soft Blue", hex: "#DCEEFF" },
  { id: "lilac", name: "Lilac", hex: "#C8B5E8" },
  { id: "professional-lavender", name: "Professional Lavender", hex: "#E6DDF5" },
  { id: "warm-beige", name: "Warm Beige", hex: "#E8D5B9" },
  { id: "cream", name: "Cream", hex: "#FFF1DC" },
  { id: "light-peach", name: "Light Peach", hex: "#F5D5C7" },
  { id: "premium-charcoal", name: "Premium Charcoal", hex: "#343A40" },
];

const HEX_RE = /^#?([0-9a-f]{6}|[0-9a-f]{3})$/i;
const RGB_RE = /^(?:rgb\()?\s*(\d{1,3})\s*[, ]\s*(\d{1,3})\s*[, ]\s*(\d{1,3})\s*\)?$/i;

/** Parses "#1A2B3C", "#abc", "rgb(10, 20, 30)" or "10,20,30". Returns normalized #RRGGBB or null. */
export function parseColor(input: string): string | null {
  const value = input.trim();
  const hex = value.match(HEX_RE);
  if (hex) {
    let h = hex[1];
    if (h.length === 3) h = h.split("").map((c) => c + c).join("");
    return `#${h.toUpperCase()}`;
  }
  const rgb = value.match(RGB_RE);
  if (rgb) {
    const parts = rgb.slice(1, 4).map(Number);
    if (parts.every((p) => p >= 0 && p <= 255)) {
      return "#" + parts.map((p) => p.toString(16).padStart(2, "0")).join("").toUpperCase();
    }
  }
  return null;
}
