export interface PhotoSize {
  id: string;
  name: string;
  widthMm: number;
  heightMm: number;
}

export interface SheetSize {
  id: string;
  name: string;
  widthMm: number;
  heightMm: number;
}

export const PHOTO_SIZES: PhotoSize[] = [
  { id: "40x50", name: "40 × 50 mm", widthMm: 40, heightMm: 50 },
  { id: "35x45", name: "35 × 45 mm", widthMm: 35, heightMm: 45 },
  { id: "2x2in", name: "2 × 2 inch", widthMm: 50.8, heightMm: 50.8 },
];

export const SHEET_SIZES: SheetSize[] = [
  { id: "4x6in", name: "4 × 6 inch print", widthMm: 101.6, heightMm: 152.4 },
  { id: "a4", name: "A4", widthMm: 210, heightMm: 297 },
];

export const DPI_OPTIONS = [150, 300, 600] as const;

export function mmToPx(mm: number, dpi: number): number {
  return Math.round((mm / 25.4) * dpi);
}

export interface SheetLayout {
  columns: number;
  rows: number;
  capacity: number;
  placed: number;
  positions: { x: number; y: number }[]; // millimetres from sheet top-left
  fitsAny: boolean;
}

/**
 * Lays out as many photos as fit on a sheet (up to `copies`), with margins and gaps.
 * Pure geometry: no image processing involved.
 */
export function layoutSheet(opts: {
  photo: { widthMm: number; heightMm: number };
  sheet: { widthMm: number; heightMm: number };
  marginMm: number;
  gapMm: number;
  copies: number;
}): SheetLayout {
  const { photo, sheet, marginMm, gapMm, copies } = opts;
  const usableW = sheet.widthMm - 2 * marginMm;
  const usableH = sheet.heightMm - 2 * marginMm;
  const columns = Math.max(0, Math.floor((usableW + gapMm) / (photo.widthMm + gapMm)));
  const rows = Math.max(0, Math.floor((usableH + gapMm) / (photo.heightMm + gapMm)));
  const capacity = columns * rows;
  const placed = Math.min(capacity, Math.max(0, Math.floor(copies)));
  const positions: { x: number; y: number }[] = [];
  for (let i = 0; i < placed; i++) {
    const col = i % columns;
    const row = Math.floor(i / columns);
    positions.push({
      x: marginMm + col * (photo.widthMm + gapMm),
      y: marginMm + row * (photo.heightMm + gapMm),
    });
  }
  return { columns, rows, capacity, placed, positions, fitsAny: capacity > 0 };
}
