export interface OutfitPreset {
  id: string;
  name: string;
  description: string;
  swatch: string;
}

export const OUTFIT_PRESETS: OutfitPreset[] = [
  { id: "premium-formal-shirt", name: "Premium formal shirt", description: "Crisp white dress shirt", swatch: "#FFFFFF" },
  { id: "collared-shirt", name: "Professional collared shirt", description: "Light blue collared shirt", swatch: "#BFD9EE" },
  { id: "navy-polo", name: "Navy polo", description: "Navy blue polo shirt", swatch: "#1F3A5F" },
  { id: "blue-polo", name: "Blue polo", description: "Royal blue polo shirt", swatch: "#2563EB" },
  { id: "elegant-panjabi", name: "Elegant Panjabi", description: "Traditional elegant Panjabi", swatch: "#E8D5B9" },
  { id: "business-attire", name: "Formal business attire", description: "Dark suit and tie", swatch: "#343A40" },
  { id: "school-uniform", name: "School uniform", description: "Standard school uniform", swatch: "#142B4A" },
];
