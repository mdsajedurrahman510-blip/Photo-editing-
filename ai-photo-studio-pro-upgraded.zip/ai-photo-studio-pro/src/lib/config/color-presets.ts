export interface ColorGradePreset {
  id: string;
  name: string;
  description: string;
}

export const COLOR_GRADE_PRESETS: ColorGradePreset[] = [
  { id: "natural-studio", name: "Natural Studio", description: "Neutral studio look, true skin tones" },
  { id: "clean-portrait", name: "Clean Portrait", description: "Slight lift and clarity" },
  { id: "soft-professional", name: "Soft Professional", description: "Gentle contrast, softer highlights" },
  { id: "bright-airy", name: "Bright & Airy", description: "Lifted exposure, light shadows" },
  { id: "neutral-corporate", name: "Neutral Corporate", description: "Accurate white balance, minimal colour" },
  { id: "warm-studio", name: "Warm Studio", description: "Subtle warm white balance" },
  { id: "cool-professional", name: "Cool Professional", description: "Subtle cool white balance" },
  { id: "premium-matte", name: "Premium Matte", description: "Lowered blacks, controlled contrast" },
];
