/**
 * Integration contract for the AI processing engine.
 *
 * Phase 1 defines the contract and a health check only. The Python/FastAPI
 * engine implementing it arrives in Phase 2+. The UI must never fake results:
 * when no engine is reachable, status is reported as "not-connected".
 */

export type StageId =
  | "quality-assessment"
  | "exposure"
  | "denoise"
  | "jpeg-artifacts"
  | "deblur"
  | "upscale"
  | "white-balance"
  | "contrast"
  | "color"
  | "skin-preservation"
  | "hair-detail"
  | "eye-detail"
  | "clothing-texture"
  | "background-cleanup"
  | "face-protection";

export interface PipelineStage {
  id: StageId;
  label: string;
  /** Model required for this stage, or null for classical OpenCV/Pillow steps. */
  model: string | null;
  /** Whether the stage touches face pixels and therefore runs under identity protection. */
  touchesFace: boolean;
}

export const PIPELINE_STAGES: PipelineStage[] = [
  { id: "quality-assessment", label: "Quality assessment", model: null, touchesFace: false },
  { id: "exposure", label: "Exposure correction", model: null, touchesFace: false },
  { id: "denoise", label: "Noise reduction", model: null, touchesFace: false },
  { id: "jpeg-artifacts", label: "JPEG artifact removal", model: null, touchesFace: false },
  { id: "deblur", label: "Deblur & conservative sharpen", model: null, touchesFace: true },
  { id: "upscale", label: "AI resolution upscaling (optional model)", model: "Real-ESRGAN weights", touchesFace: false },
  { id: "white-balance", label: "White balance", model: null, touchesFace: false },
  { id: "contrast", label: "Natural contrast & highlight/shadow recovery", model: null, touchesFace: false },
  { id: "color", label: "Color correction", model: null, touchesFace: false },
  { id: "skin-preservation", label: "Skin texture preservation", model: null, touchesFace: true },
  { id: "hair-detail", label: "Hair detail & edge preservation", model: null, touchesFace: false },
  { id: "eye-detail", label: "Eye detail (shape unchanged)", model: null, touchesFace: true },
  { id: "clothing-texture", label: "Clothing texture restoration", model: null, touchesFace: false },
  { id: "background-cleanup", label: "Subject segmentation & background replacement", model: "rembg weights (optional)", touchesFace: false },
  { id: "face-protection", label: "Non-generative identity-first processing policy", model: null, touchesFace: true },
];

export type EngineStatus =
  | { state: "not-configured" }
  | { state: "not-connected"; url: string; error: string }
  | { state: "connected"; url: string; version?: string; models: string[] };

export interface EngineHealthResponse {
  status: EngineStatus;
  checkedAt: string;
}
