/**
 * Identity-preservation rules. These are product requirements, enforced at
 * every integration point. Engines must not expose operations that break them.
 */
export const IDENTITY_RULES: string[] = [
  "Never change facial identity, face shape, or facial proportions.",
  "Never apply beauty filters that reconstruct or invent facial features.",
  "Never make a person look younger or older.",
  "Never change skin tone or ethnicity.",
  "Preserve expression, eye direction, natural asymmetry, and distinctive marks.",
  "Never invent missing facial detail when restoring blurry images.",
  "Improve conservatively when the source lacks information.",
  "Protect face regions during every restoration stage.",
  "Preserve freckles, moles, scars, and permanent features.",
  "Never use customer photos for model training without explicit consent.",
];

export interface EditSettingsForPolicy {
  intensity: number;
  denoise: number;
  sharpness: number;
}

/** Returns human-readable warnings when settings raise identity-drift risk. */
export function identityWarnings(s: EditSettingsForPolicy): string[] {
  const warnings: string[] = [];
  if (s.intensity > 80) {
    warnings.push("Intensity above 80% raises the risk of facial detail being invented. Consider lowering it.");
  }
  if (s.sharpness > 75) {
    warnings.push("High sharpness can create artificial skin texture and halos on hair edges.");
  }
  if (s.denoise > 80) {
    warnings.push("Heavy denoising can smooth away real skin texture, which reads as artificial.");
  }
  return warnings;
}
