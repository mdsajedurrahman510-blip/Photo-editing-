import type { EngineHealthResponse } from "./types";

/** Client-side call to the Next.js health route. The engine URL never comes from the browser. */
export async function fetchEngineHealth(): Promise<EngineHealthResponse> {
  const res = await fetch("/api/engine/health", { cache: "no-store" });
  if (!res.ok) throw new Error(`Health check failed (HTTP ${res.status})`);
  return (await res.json()) as EngineHealthResponse;
}
