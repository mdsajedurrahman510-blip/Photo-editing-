"use client";

import { useCallback, useEffect, useState } from "react";
import { fetchEngineHealth } from "./client";
import type { EngineStatus } from "./types";

export function useEngineStatus() {
  const [status, setStatus] = useState<EngineStatus | null>(null);
  const [checkedAt, setCheckedAt] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Initial load: state is only updated from promise callbacks, never synchronously in the effect.
  useEffect(() => {
    let cancelled = false;
    fetchEngineHealth()
      .then((res) => {
        if (cancelled) return;
        setStatus(res.status);
        setCheckedAt(res.checkedAt);
        setError(null);
      })
      .catch((err: unknown) => {
        if (!cancelled) setError(err instanceof Error ? err.message : "Health check failed");
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  // Manual recheck, triggered by user action.
  const refresh = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetchEngineHealth();
      setStatus(res.status);
      setCheckedAt(res.checkedAt);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Health check failed");
    } finally {
      setLoading(false);
    }
  }, []);

  return { status, checkedAt, loading, error, refresh };
}
