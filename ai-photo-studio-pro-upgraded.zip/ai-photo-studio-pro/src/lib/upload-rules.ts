/**
 * Client-side upload validation. This is a first line of defence only:
 * the Phase 2 engine must re-validate type (by magic bytes), size and decodability.
 */
export const IMAGE_TYPES = ["image/jpeg", "image/png", "image/webp"] as const;

export const MAX_IMAGE_BYTES = 50 * 1024 * 1024; // 50 MB

export interface ValidationResult {
  ok: boolean;
  error?: string;
}

export function validateImage(file: File): ValidationResult {
  if (!(IMAGE_TYPES as readonly string[]).includes(file.type)) {
    return { ok: false, error: `"${file.name}" is not a supported image (JPG, PNG or WebP).` };
  }
  if (file.size > MAX_IMAGE_BYTES) {
    return { ok: false, error: `"${file.name}" is larger than 50 MB.` };
  }
  if (file.size === 0) {
    return { ok: false, error: `"${file.name}" is empty.` };
  }
  return { ok: true };
}

