interface ZipEntry { name: string; data: Uint8Array }

function crc32(bytes: Uint8Array): number {
  let crc = 0xffffffff;
  for (const byte of bytes) {
    crc ^= byte;
    for (let j = 0; j < 8; j++) crc = (crc >>> 1) ^ (0xedb88320 & -(crc & 1));
  }
  return (crc ^ 0xffffffff) >>> 0;
}

function u16(view: DataView, offset: number, value: number) { view.setUint16(offset, value, true); }
function u32(view: DataView, offset: number, value: number) { view.setUint32(offset, value >>> 0, true); }

/** Builds a standards-compliant ZIP archive using STORE (no compression). */
export async function createZip(files: { name: string; blob: Blob }[]): Promise<Blob> {
  const encoder = new TextEncoder();
  const entries: ZipEntry[] = [];
  for (const file of files) entries.push({ name: file.name.replace(/[\\/:*?"<>|]/g, "_").slice(0, 180), data: new Uint8Array(await file.blob.arrayBuffer()) });
  const chunks: Uint8Array[] = [];
  const central: Uint8Array[] = [];
  let offset = 0;
  for (const entry of entries) {
    const name = encoder.encode(entry.name);
    const crc = crc32(entry.data);
    const local = new Uint8Array(30 + name.length);
    const lv = new DataView(local.buffer);
    u32(lv, 0, 0x04034b50); u16(lv, 4, 20); u16(lv, 6, 0x0800); u16(lv, 8, 0);
    u32(lv, 14, crc); u32(lv, 18, entry.data.length); u32(lv, 22, entry.data.length);
    u16(lv, 26, name.length); u16(lv, 28, 0); local.set(name, 30);
    chunks.push(local, entry.data);

    const cd = new Uint8Array(46 + name.length);
    const cv = new DataView(cd.buffer);
    u32(cv, 0, 0x02014b50); u16(cv, 4, 20); u16(cv, 6, 20); u16(cv, 8, 0x0800); u16(cv, 10, 0);
    u32(cv, 16, crc); u32(cv, 20, entry.data.length); u32(cv, 24, entry.data.length);
    u16(cv, 28, name.length); u16(cv, 30, 0); u16(cv, 32, 0); u16(cv, 34, 0); u16(cv, 36, 0);
    u32(cv, 38, 0); u32(cv, 42, offset); cd.set(name, 46);
    central.push(cd);
    offset += local.length + entry.data.length;
  }
  const centralSize = central.reduce((sum, c) => sum + c.length, 0);
  const end = new Uint8Array(22);
  const ev = new DataView(end.buffer);
  u32(ev, 0, 0x06054b50); u16(ev, 4, 0); u16(ev, 6, 0);
  u16(ev, 8, entries.length); u16(ev, 10, entries.length);
  u32(ev, 12, centralSize); u32(ev, 16, offset); u16(ev, 20, 0);
  const parts = [...chunks, ...central, end].map((chunk) => { const copy = new ArrayBuffer(chunk.byteLength); new Uint8Array(copy).set(chunk); return copy; });
  return new Blob(parts, { type: "application/zip" });
}
