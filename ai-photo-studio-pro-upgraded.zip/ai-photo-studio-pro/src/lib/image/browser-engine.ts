export interface BrowserEnhancementOptions {
  brightness?: number;
  contrast?: number;
  saturation?: number;
  denoise?: number;
  sharpness?: number;
  faceLight?: number;
  autoLight?: boolean;
  quality?: number;
}

export interface BrowserEnhancementResult {
  blob: Blob;
  width: number;
  height: number;
  engine: "browser-classical";
  notes: string[];
}

function canvasBlob(canvas: HTMLCanvasElement, type = "image/jpeg", quality = 0.95): Promise<Blob> {
  return new Promise((resolve, reject) => {
    canvas.toBlob((blob) => (blob ? resolve(blob) : reject(new Error("The browser could not encode this image."))), type, quality);
  });
}

async function imageToCanvas(file: Blob, maxPixels = 12_000_000): Promise<HTMLCanvasElement> {
  const bitmap = await createImageBitmap(file, { imageOrientation: "from-image" });
  const scale = Math.min(1, Math.sqrt(maxPixels / (bitmap.width * bitmap.height)));
  const canvas = document.createElement("canvas");
  canvas.width = Math.max(1, Math.round(bitmap.width * scale));
  canvas.height = Math.max(1, Math.round(bitmap.height * scale));
  const ctx = canvas.getContext("2d", { willReadFrequently: true });
  if (!ctx) throw new Error("Canvas is not available in this browser.");
  ctx.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
  bitmap.close();
  return canvas;
}

/**
 * CPU-only, non-generative photo finishing for a browser. It changes pixel tone,
 * not facial geometry. It is not a substitute for learned AI restoration models.
 */
export async function enhanceImageInBrowser(
  file: File | Blob,
  options: BrowserEnhancementOptions = {},
): Promise<BrowserEnhancementResult> {
  const canvas = await imageToCanvas(file);
  const ctx = canvas.getContext("2d", { willReadFrequently: true });
  if (!ctx) throw new Error("Canvas context is unavailable.");

  const { width, height } = canvas;
  const image = ctx.getImageData(0, 0, width, height);
  const px = image.data;
  const brightness = Math.max(-40, Math.min(40, options.brightness ?? 0));
  const contrast = Math.max(-30, Math.min(30, options.contrast ?? 6));
  const saturation = Math.max(-30, Math.min(30, options.saturation ?? 0));
  const denoise = Math.max(0, Math.min(100, options.denoise ?? 22));
  const sharpness = Math.max(0, Math.min(100, options.sharpness ?? 24));
  const faceLight = Math.max(0, Math.min(60, options.faceLight ?? 18));

  // Estimate exposure from a deterministic sample to avoid expensive full scans.
  let luminanceSum = 0;
  let samples = 0;
  const stride = Math.max(4, Math.floor((width * height) / 120_000) * 4);
  for (let i = 0; i < px.length; i += stride) {
    luminanceSum += (0.2126 * px[i] + 0.7152 * px[i + 1] + 0.0722 * px[i + 2]) / 255;
    samples++;
  }
  const mean = samples ? luminanceSum / samples : 0.48;
  const autoEv = options.autoLight === false ? 0 : Math.max(-0.28, Math.min(0.34, Math.log2(0.48 / Math.max(0.08, mean)) * 0.24));
  const exposureGain = 2 ** (autoEv + (brightness / 100) * 0.75);
  const contrastGain = 1 + contrast / 100;
  const saturationGain = 1 + saturation / 100;
  const faceLift = faceLight / 100;

  for (let i = 0; i < px.length; i += 4) {
    let r = px[i] * exposureGain;
    let g = px[i + 1] * exposureGain;
    let b = px[i + 2] * exposureGain;
    r = (r - 127.5) * contrastGain + 127.5;
    g = (g - 127.5) * contrastGain + 127.5;
    b = (b - 127.5) * contrastGain + 127.5;

    const y = 0.2126 * r + 0.7152 * g + 0.0722 * b;
    // Gently raise low-mid tones without aggressively clipping highlights.
    const shadowLift = Math.max(0, 105 - y) / 105 * (faceLift * 12);
    r += shadowLift; g += shadowLift; b += shadowLift;
    r = y + (r - y) * saturationGain;
    g = y + (g - y) * saturationGain;
    b = y + (b - y) * saturationGain;
    px[i] = Math.max(0, Math.min(255, r));
    px[i + 1] = Math.max(0, Math.min(255, g));
    px[i + 2] = Math.max(0, Math.min(255, b));
  }
  ctx.putImageData(image, 0, 0);

  // Mild blur blend as a conservative browser fallback for fine sensor grain.
  if (denoise > 0) {
    const soft = document.createElement("canvas");
    soft.width = width; soft.height = height;
    const softCtx = soft.getContext("2d");
    if (softCtx) {
      softCtx.filter = `blur(${(denoise / 100) * 0.55}px)`;
      softCtx.drawImage(canvas, 0, 0);
      ctx.globalAlpha = (denoise / 100) * 0.12;
      ctx.drawImage(soft, 0, 0);
      ctx.globalAlpha = 1;
    }
  }

  // Conservative unsharp mask. It enhances captured edges; it does not synthesize details.
  if (sharpness > 0) {
    const source = document.createElement("canvas");
    source.width = width; source.height = height;
    const sourceCtx = source.getContext("2d", { willReadFrequently: true });
    if (sourceCtx) {
      sourceCtx.drawImage(canvas, 0, 0);
      const blurred = document.createElement("canvas");
      blurred.width = width; blurred.height = height;
      const blurCtx = blurred.getContext("2d", { willReadFrequently: true });
      if (blurCtx) {
        blurCtx.filter = "blur(1px)";
        blurCtx.drawImage(source, 0, 0);
        blurCtx.filter = "none";
        const originalData = sourceCtx.getImageData(0, 0, width, height);
        const blurData = blurCtx.getImageData(0, 0, width, height);
        const amount = (sharpness / 100) * 0.38;
        for (let i = 0; i < originalData.data.length; i += 4) {
          for (let c = 0; c < 3; c++) {
            const v = originalData.data[i + c] + (originalData.data[i + c] - blurData.data[i + c]) * amount;
            originalData.data[i + c] = Math.max(0, Math.min(255, v));
          }
        }
        ctx.putImageData(originalData, 0, 0);
      }
    }
  }

  const rawBlob = await canvasBlob(canvas, "image/jpeg", options.quality ?? 0.94);
  const blob = await setJpegDpi(rawBlob, 300);
  return {
    blob,
    width,
    height,
    engine: "browser-classical",
    notes: [
      "Applied non-generative tone, shadow, denoise-blend and edge enhancement in this browser.",
      "Facial geometry was not warped or reconstructed.",
      "This is classical image processing, not a generative AI restoration model.",
      "No automatic background removal or clothing replacement was performed.",
    ],
  };
}

export async function renderPhotoToSize(
  file: File | Blob,
  widthMm: number,
  heightMm: number,
  dpi: number,
  background = "#FFFFFF",
  fit: "contain" | "cover" = "cover",
): Promise<Blob> {
  if (![widthMm, heightMm, dpi].every(Number.isFinite) || widthMm <= 0 || heightMm <= 0 || dpi < 72 || dpi > 1200) {
    throw new Error("Enter valid physical dimensions and DPI.");
  }
  const w = Math.round((widthMm / 25.4) * dpi);
  const h = Math.round((heightMm / 25.4) * dpi);
  if (w * h > 30_000_000) throw new Error("This print size is too large for browser memory. Choose a lower DPI or smaller size.");
  const bitmap = await createImageBitmap(file, { imageOrientation: "from-image" });
  const canvas = document.createElement("canvas");
  canvas.width = w; canvas.height = h;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Canvas is unavailable.");
  ctx.fillStyle = background;
  ctx.fillRect(0, 0, w, h);
  const scale = fit === "cover" ? Math.max(w / bitmap.width, h / bitmap.height) : Math.min(w / bitmap.width, h / bitmap.height);
  const dw = bitmap.width * scale;
  const dh = bitmap.height * scale;
  ctx.drawImage(bitmap, (w - dw) / 2, (h - dh) / 2, dw, dh);
  bitmap.close();
  return setJpegDpi(await canvasBlob(canvas, "image/jpeg", 0.96), dpi);
}

export async function renderPrintSheet(
  file: File | Blob,
  photoWidthMm: number,
  photoHeightMm: number,
  sheetWidthMm: number,
  sheetHeightMm: number,
  copies: number,
  marginMm: number,
  gapMm: number,
  dpi: number,
  background = "#FFFFFF",
): Promise<Blob> {
  const sw = Math.round((sheetWidthMm / 25.4) * dpi);
  const sh = Math.round((sheetHeightMm / 25.4) * dpi);
  if (sw * sh > 32_000_000) throw new Error("The selected print sheet exceeds the safe browser canvas size.");
  const pw = Math.round((photoWidthMm / 25.4) * dpi);
  const ph = Math.round((photoHeightMm / 25.4) * dpi);
  const margin = Math.round((marginMm / 25.4) * dpi);
  const gap = Math.round((gapMm / 25.4) * dpi);
  const cols = Math.max(0, Math.floor((sw - 2 * margin + gap) / (pw + gap)));
  const rows = Math.max(0, Math.floor((sh - 2 * margin + gap) / (ph + gap)));
  const capacity = cols * rows;
  const count = Math.min(Math.max(0, Math.floor(copies)), capacity);
  if (!count) throw new Error("No photo fits on this sheet. Reduce margins/gaps or choose another sheet size.");

  const bitmap = await createImageBitmap(file, { imageOrientation: "from-image" });
  const canvas = document.createElement("canvas");
  canvas.width = sw; canvas.height = sh;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Canvas is unavailable.");
  ctx.fillStyle = "#FFFFFF"; ctx.fillRect(0, 0, sw, sh);
  const scale = Math.max(pw / bitmap.width, ph / bitmap.height);
  const dw = bitmap.width * scale, dh = bitmap.height * scale;
  const cropX = (dw - pw) / 2, cropY = (dh - ph) / 2;
  for (let i = 0; i < count; i++) {
    const x = margin + (i % cols) * (pw + gap);
    const y = margin + Math.floor(i / cols) * (ph + gap);
    ctx.save(); ctx.beginPath(); ctx.rect(x, y, pw, ph); ctx.clip();
    ctx.fillStyle = background; ctx.fillRect(x, y, pw, ph);
    ctx.drawImage(bitmap, -cropX + x, -cropY + y, dw, dh);
    ctx.restore();
    ctx.strokeStyle = "#CBD5E1"; ctx.lineWidth = Math.max(1, dpi / 300); ctx.strokeRect(x, y, pw, ph);
  }
  bitmap.close();
  return setJpegDpi(await canvasBlob(canvas, "image/jpeg", 0.96), dpi);
}


/** Set JFIF density metadata so photo apps/printers can read the requested DPI. */
export async function setJpegDpi(blob: Blob, dpi: number): Promise<Blob> {
  const bytes = new Uint8Array(await blob.arrayBuffer());
  for (let i = 2; i + 18 < bytes.length; i++) {
    if (bytes[i] === 0xff && bytes[i + 1] === 0xe0 && bytes[i + 4] === 0x4a && bytes[i + 5] === 0x46 && bytes[i + 6] === 0x49 && bytes[i + 7] === 0x46 && bytes[i + 8] === 0x00) {
      bytes[i + 11] = 1; // density units: dots per inch
      const safeDpi = Math.max(1, Math.min(65535, Math.round(dpi)));
      bytes[i + 12] = (safeDpi >> 8) & 255; bytes[i + 13] = safeDpi & 255;
      bytes[i + 14] = (safeDpi >> 8) & 255; bytes[i + 15] = safeDpi & 255;
      break;
    }
  }
  const safeBuffer = new ArrayBuffer(bytes.byteLength); new Uint8Array(safeBuffer).set(bytes);
  return new Blob([safeBuffer], { type: "image/jpeg" });
}

/** Create a one-page PDF with the given physical page dimensions and JPEG image. */
export async function jpegToPdf(jpeg: Blob, widthMm: number, heightMm: number): Promise<Blob> {
  const image = new Uint8Array(await jpeg.arrayBuffer());
  const bitmap = await createImageBitmap(jpeg);
  const imageWidth = bitmap.width, imageHeight = bitmap.height; bitmap.close();
  const w = widthMm * 72 / 25.4, h = heightMm * 72 / 25.4;
  const enc = new TextEncoder();
  const chunks: Uint8Array[] = [enc.encode("%PDF-1.4\n%âãÏÓ\n")];
  let length = chunks[0].length;
  const offsets: number[] = [0];
  const push = (b: Uint8Array) => { chunks.push(b); length += b.length; };
  const object = (id: number, body: Uint8Array) => { offsets[id] = length; push(enc.encode(`${id} 0 obj\n`)); push(body); push(enc.encode("\nendobj\n")); };
  object(1, enc.encode("<< /Type /Catalog /Pages 2 0 R >>"));
  object(2, enc.encode("<< /Type /Pages /Kids [3 0 R] /Count 1 >>"));
  object(3, enc.encode(`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${w.toFixed(3)} ${h.toFixed(3)}] /Resources << /XObject << /Im0 5 0 R >> >> /Contents 4 0 R >>`));
  const content = enc.encode(`q\n${w.toFixed(3)} 0 0 ${h.toFixed(3)} 0 0 cm\n/Im0 Do\nQ`);
  object(4, enc.encode(`<< /Length ${content.length} >>\nstream\n${new TextDecoder().decode(content)}\nendstream`));
  offsets[5] = length; push(enc.encode(`5 0 obj\n<< /Type /XObject /Subtype /Image /Width ${imageWidth} /Height ${imageHeight} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${image.length} >>\nstream\n`)); push(image); push(enc.encode("\nendstream\nendobj\n"));
  const xrefOffset = length;
  push(enc.encode(`xref\n0 6\n0000000000 65535 f \n${offsets.slice(1, 6).map((o) => `${String(o).padStart(10, "0")} 00000 n \n`).join("")}trailer\n<< /Size 6 /Root 1 0 R >>\nstartxref\n${xrefOffset}\n%%EOF`));
  const parts = chunks.map((chunk) => { const copy = new ArrayBuffer(chunk.byteLength); new Uint8Array(copy).set(chunk); return copy; });
  return new Blob(parts, { type: "application/pdf" });
}

/** Create one paired portrait canvas. The entire source frame is retained so neither subject is cropped out. */
export async function renderPairedPortrait(
  file: File | Blob,
  widthMm: number,
  heightMm: number,
  dpi: number,
  background = "#FFFFFF",
  fit: "contain" | "cover" = "contain",
): Promise<Blob> {
  return renderPhotoToSize(file, widthMm, heightMm, dpi, background, fit);
}

export function downloadBlob(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = filename;
  document.body.appendChild(a); a.click(); a.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 30_000);
}
