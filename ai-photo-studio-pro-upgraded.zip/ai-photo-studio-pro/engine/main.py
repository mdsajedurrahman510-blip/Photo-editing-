"""AI Photo Studio Pro processing engine.

CPU-first, non-generative enhancement. Facial geometry is never synthesized or
warped. Background removal is optional and only enabled when rembg is installed.
"""
from __future__ import annotations

import io
import json
import os
from typing import Any

import cv2
import numpy as np
from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import Response
from PIL import Image, ImageOps

APP_VERSION = "2.0.0"
MAX_UPLOAD_BYTES = int(os.getenv("MAX_UPLOAD_MB", "30")) * 1024 * 1024
MAX_PIXELS = int(os.getenv("MAX_IMAGE_PIXELS", "24000000"))

app = FastAPI(title="AI Photo Studio Pro Engine", version=APP_VERSION)
app.add_middleware(
    CORSMiddleware,
    allow_origins=os.getenv("CORS_ORIGINS", "*").split(","),
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)


def _load_image(data: bytes) -> Image.Image:
    if not data or len(data) > MAX_UPLOAD_BYTES:
        raise HTTPException(status_code=413, detail=f"Upload must be between 1 byte and {MAX_UPLOAD_BYTES // (1024*1024)} MB")
    try:
        image = Image.open(io.BytesIO(data))
        image = ImageOps.exif_transpose(image).convert("RGB")
    except Exception as exc:
        raise HTTPException(status_code=400, detail="Unsupported or corrupted image file") from exc
    if image.width * image.height > MAX_PIXELS:
        scale = (MAX_PIXELS / (image.width * image.height)) ** 0.5
        image = image.resize((max(1, int(image.width * scale)), max(1, int(image.height * scale))), Image.Resampling.LANCZOS)
    return image


def _face_boxes(rgb: np.ndarray) -> list[tuple[int, int, int, int]]:
    """Best-effort face localization. Haar detection is not a biometric identity check."""
    try:
        cascade_path = cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
        cascade = cv2.CascadeClassifier(cascade_path)
        if cascade.empty():
            return []
        gray = cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY)
        boxes = cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(36, 36))
        return [(int(x), int(y), int(w), int(h)) for x, y, w, h in boxes]
    except Exception:
        return []


def _apply_face_lift(rgb: np.ndarray, boxes: list[tuple[int, int, int, int]], strength: float) -> np.ndarray:
    """Apply a very restrained feathered luminance lift to detected face areas."""
    if not boxes or strength <= 0:
        return rgb
    h, w = rgb.shape[:2]
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    mask = np.zeros((h, w), dtype=np.float32)
    for x, y, fw, fh in boxes:
        cx, cy = x + fw / 2, y + fh / 2
        rx, ry = fw * 0.72, fh * 0.82
        ellipse = np.exp(-2.0 * (((xx - cx) / max(rx, 1)) ** 2 + ((yy - cy) / max(ry, 1)) ** 2))
        mask = np.maximum(mask, ellipse)
    mask = np.clip(mask * strength, 0.0, 0.22)[..., None]
    out = rgb.astype(np.float32)
    # Lift luma gently; RGB channels are scaled together to avoid shifting hue.
    luma = np.mean(out, axis=2, keepdims=True)
    lift = (255.0 - luma) * 0.10
    out = out + lift * mask
    return np.clip(out, 0, 255).astype(np.uint8)


def _enhance(rgb: np.ndarray, settings: dict[str, Any]) -> tuple[np.ndarray, dict[str, Any]]:
    original_h, original_w = rgb.shape[:2]
    face_boxes = _face_boxes(rgb)

    # Bound expensive classical denoising to a practical CPU workload.
    work = rgb
    max_side = 2600
    scale = min(1.0, max_side / max(original_w, original_h))
    if scale < 1:
        work = cv2.resize(rgb, (max(1, round(original_w * scale)), max(1, round(original_h * scale))), interpolation=cv2.INTER_AREA)

    denoise = float(np.clip(settings.get("denoise", 30), 0, 100))
    strength = float(np.clip(settings.get("strength", 55), 0, 100))
    sharpness = float(np.clip(settings.get("sharpness", 22), 0, 100))
    brightness = float(np.clip(settings.get("brightness", 0), -40, 40))
    contrast = float(np.clip(settings.get("contrast", 5), -30, 30))
    saturation = float(np.clip(settings.get("saturation", 0), -30, 30))
    face_light = float(np.clip(settings.get("faceLight", 25), 0, 60))

    # Mild luminance denoising preserves edges more carefully than a strong blur.
    if denoise > 0:
        hls = cv2.cvtColor(work, cv2.COLOR_RGB2LAB)
        amount = 2 + int(denoise * 0.09)
        hls[:, :, 0] = cv2.fastNlMeansDenoising(hls[:, :, 0], None, amount, 7, 21)
        work = cv2.cvtColor(hls, cv2.COLOR_LAB2RGB)

    # Adaptive exposure: adjust only when the image is materially dark/bright.
    lab = cv2.cvtColor(work, cv2.COLOR_RGB2LAB)
    l = lab[:, :, 0].astype(np.float32) / 255.0
    mean_l = float(np.mean(l))
    target = 0.48
    auto_ev = float(np.clip(np.log2(max(0.08, target) / max(mean_l, 0.08)) * 0.28, -0.35, 0.38))
    manual_ev = brightness / 100.0 * 0.8
    ev = auto_ev * (strength / 100.0) + manual_ev
    gain = 2.0 ** ev
    work_f = work.astype(np.float32) * gain
    work = np.clip(work_f, 0, 255).astype(np.uint8)

    # Controlled contrast and saturation in HSV/float space.
    if contrast != 0:
        c = 1.0 + contrast / 100.0
        work = np.clip((work.astype(np.float32) - 127.5) * c + 127.5, 0, 255).astype(np.uint8)
    if saturation != 0:
        hsv = cv2.cvtColor(work, cv2.COLOR_RGB2HSV).astype(np.float32)
        hsv[:, :, 1] = np.clip(hsv[:, :, 1] * (1.0 + saturation / 100.0), 0, 255)
        work = cv2.cvtColor(hsv.astype(np.uint8), cv2.COLOR_HSV2RGB)

    # Mild CLAHE on luminance only; cap clip limit to avoid crunchy skin.
    if strength > 20:
        lab = cv2.cvtColor(work, cv2.COLOR_RGB2LAB)
        clahe = cv2.createCLAHE(clipLimit=1.15 + strength / 250.0, tileGridSize=(8, 8))
        lab[:, :, 0] = clahe.apply(lab[:, :, 0])
        work = cv2.cvtColor(lab, cv2.COLOR_LAB2RGB)

    # Conservative unsharp masking. It does not create or reconstruct facial geometry.
    if sharpness > 0:
        blur = cv2.GaussianBlur(work, (0, 0), 1.0)
        amount = (sharpness / 100.0) * 0.65
        work = cv2.addWeighted(work, 1.0 + amount, blur, -amount, 0)

    # Face-region lift is deliberately subtle and uses detected bounding areas only.
    # Detection is heuristic; no face restoration or identity embedding is performed.
    if face_boxes and face_light > 0:
        scaled_boxes = [(round(x * scale), round(y * scale), round(w * scale), round(h * scale)) for x, y, w, h in face_boxes]
        work = _apply_face_lift(work, scaled_boxes, face_light / 100.0)

    if work.shape[1] != original_w or work.shape[0] != original_h:
        work = cv2.resize(work, (original_w, original_h), interpolation=cv2.INTER_CUBIC)

    meta = {
        "faceCount": len(face_boxes),
        "width": original_w,
        "height": original_h,
        "pipeline": ["quality-analysis", "luminance-denoise", "adaptive-exposure", "tone-contrast", "color-balance", "conservative-sharpen", "face-lighting"],
        "identityMode": "non-generative; no geometric face edits",
        "notes": ["Face detection is heuristic and is not an identity verification system.", "No AI hallucination-based face reconstruction is used."],
    }
    return work, meta


@app.get("/health")
def health() -> dict[str, Any]:
    models = ["opencv-classical-photo-enhancement", "haar-face-localization"]
    try:
        import rembg  # noqa: F401
        models.append("rembg-background-segmentation")
    except Exception:
        pass
    return {"version": APP_VERSION, "models": models, "mode": "CPU-first; non-generative"}


@app.post("/process")
async def process_photo(image: UploadFile = File(...), settings: str = Form("{}")) -> Response:
    raw = await image.read()
    try:
        options = json.loads(settings or "{}")
        if not isinstance(options, dict):
            options = {}
    except json.JSONDecodeError:
        raise HTTPException(status_code=400, detail="Invalid processing settings")
    pil = _load_image(raw)
    rgb = np.asarray(pil)
    output, meta = _enhance(rgb, options)
    result = Image.fromarray(output)
    buf = io.BytesIO()
    result.save(buf, format="JPEG", quality=95, optimize=True, dpi=(300, 300))
    headers = {
        "X-Photo-Metadata": json.dumps(meta, separators=(",", ":")),
        "X-Processing-Engine": "AI Photo Studio Pro CPU Engine",
    }
    return Response(buf.getvalue(), media_type="image/jpeg", headers=headers)


@app.post("/detect-faces")
async def detect_faces(image: UploadFile = File(...)) -> dict[str, Any]:
    pil = _load_image(await image.read())
    rgb = np.asarray(pil)
    boxes = _face_boxes(rgb)
    return {
        "count": len(boxes),
        "faces": [{"x": x, "y": y, "width": w, "height": h} for x, y, w, h in boxes],
        "image": {"width": pil.width, "height": pil.height},
        "note": "Haar detection is approximate. Confirm subject crops manually before passport printing.",
    }


@app.post("/remove-background")
async def remove_background(image: UploadFile = File(...), color: str = Form("#00A8E8")) -> Response:
    raw = await image.read()
    pil = _load_image(raw)
    try:
        from rembg import remove  # type: ignore
    except Exception as exc:
        raise HTTPException(status_code=503, detail="Background segmentation model is not installed. Install the optional rembg extra and its model weights on the engine host.") from exc
    try:
        rgba = remove(pil.convert("RGBA"))
        hex_color = color.lstrip("#")
        if len(hex_color) != 6:
            raise ValueError("Invalid HEX color")
        bg = Image.new("RGBA", rgba.size, tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4)) + (255,))
        bg.alpha_composite(rgba)
        out = io.BytesIO()
        bg.convert("RGB").save(out, format="JPEG", quality=95, optimize=True)
        return Response(out.getvalue(), media_type="image/jpeg", headers={"X-Processing-Engine": "rembg background segmentation"})
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Background segmentation failed: {exc}") from exc
