import io

import numpy as np
from fastapi.testclient import TestClient
from PIL import Image

from engine.main import app

client = TestClient(app)


def sample_jpeg() -> bytes:
    arr = np.zeros((180, 140, 3), dtype=np.uint8)
    arr[:, :, 0] = 90
    arr[:, :, 1] = 100
    arr[:, :, 2] = 115
    image = Image.fromarray(arr)
    stream = io.BytesIO()
    image.save(stream, format="JPEG")
    return stream.getvalue()


def test_health_reports_classical_engine():
    response = client.get("/health")
    assert response.status_code == 200
    body = response.json()
    assert body["version"]
    assert "opencv-classical-photo-enhancement" in body["models"]


def test_process_returns_jpeg_and_keeps_dimensions():
    response = client.post(
        "/process",
        files={"image": ("sample.jpg", sample_jpeg(), "image/jpeg")},
        data={"settings": '{"brightness":4,"denoise":10,"sharpness":10}'},
    )
    assert response.status_code == 200
    assert response.headers["content-type"].startswith("image/jpeg")
    assert "X-Photo-Metadata" in response.headers
    output = Image.open(io.BytesIO(response.content))
    assert output.size == (140, 180)


def test_invalid_image_is_rejected():
    response = client.post(
        "/process",
        files={"image": ("bad.jpg", b"not an image", "image/jpeg")},
        data={"settings": "{}"},
    )
    assert response.status_code == 400
